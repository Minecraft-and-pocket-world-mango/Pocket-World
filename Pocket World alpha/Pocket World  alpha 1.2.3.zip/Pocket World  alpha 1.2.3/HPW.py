import os
import sys
import subprocess
from pathlib import Path

def find_game_script():
    """在指定路径中查找第一个 .py 文件"""
    candidates = [
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.2.3/code"),
        Path("D:/Pocket World  alpha 1.2.3/code")
    ]
    for p in candidates:
        if p.exists() and p.is_dir():
            py_files = list(p.glob("*.py"))
            if py_files:
                return py_files[0]  # 返回第一个找到的 .py
    return None

def main():
    script = find_game_script()
    if script is None:
        input("❌ 未找到游戏脚本！请检查以下路径是否存在 .py 文件：\n"
              "  C:\\Users\\Administrator\\Desktop\\Pocket World  alpha 1.2.3\\code\n"
              "  D:\\Pocket World  alpha 1.2.3\\code\n"
              "按 Enter 退出...")
        return

    print(f"✅ 找到游戏脚本：{script}")
    print("正在启动游戏，请稍候...")

    # 使用当前 Python 解释器运行脚本
    # 如果启动器本身是 exe，sys.executable 可能就是启动器自身，所以需判断
    python_exe = sys.executable
    if python_exe.lower().endswith("launcher.exe"):
        # 若启动器本身是 exe，尝试用系统 python 命令
        python_exe = "python"  # 或 "python3"

    try:
        subprocess.run([python_exe, str(script)], check=True)
    except Exception as e:
        print(f"启动失败：{e}")
        input("按 Enter 退出...")

if __name__ == "__main__":
    main()