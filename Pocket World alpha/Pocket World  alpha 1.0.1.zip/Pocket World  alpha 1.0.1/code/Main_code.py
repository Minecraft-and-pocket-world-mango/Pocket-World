from collections import defaultdict
import random
import math
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina import *
import os
import sys
import importlib.util
from pathlib import Path

# ---------- 动态加载外部 mod ----------


def load_mods_from_path(base_path):
    mod_path = Path(base_path) / "mode"
    if not mod_path.exists() or not mod_path.is_dir():
        return
    print(f"发现 mod 目录: {mod_path}")
    for py_file in mod_path.glob("*.py"):
        try:
            module_name = py_file.stem
            spec = importlib.util.spec_from_file_location(module_name, py_file)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
                print(f"  已加载 mod: {module_name}")
        except Exception as e:
            print(f"  加载 {py_file.name} 失败: {e}")


for drive in ["C:/", "D:/"]:
    pocket_world_path = Path(drive) / "Pocket World"
    if pocket_world_path.exists() and pocket_world_path.is_dir():
        load_mods_from_path(pocket_world_path)

# ---------- 游戏主程序 ----------

app = Ursina()
window.title = 'PocketWorld alpha 1.0.3 (动物版 + 模组支持)'
Text.default_font = '微软雅黑'

# ---------- 游戏参数 ----------
WORLD_SIZE = 256
CHUNK_SIZE = 16
WORLD_HEIGHT_LIMIT = 64
BASE_HEIGHT = 8
AMPLITUDE = 10
SCALE = 40.0

BLOCK_TYPES = {
    'grass':       color.rgb(87, 127, 47),
    'dirt':        color.rgb(98, 67, 28),
    'stone':       color.rgb(127, 127, 127),
    'bedrock':     color.rgb(50, 50, 50),
    'wood':        color.rgb(139, 69, 19),
    'leaves':      color.rgb(34, 139, 34),
    'flower_red':  color.rgb(255, 80, 80),
    'flower_yellow': color.rgb(255, 255, 80),
    'tall_grass':  color.rgb(80, 160, 80),
    'water':       color.rgb(64, 164, 223, 180)
}
current_block_type = 'grass'

chunks = {}
animals = []

crosshair = Entity(model='quad', scale=(0.02, 0.02), parent=camera.ui,
                   texture='white_cube', color=color.white)

spawn_point = (WORLD_SIZE//2, 10, WORLD_SIZE//2)

# ---------- Perlin 噪声 ----------


class PerlinNoise:
    def __init__(self, seed=42):
        random.seed(seed)
        self.p = list(range(256))
        random.shuffle(self.p)
        self.p += self.p

    def fade(self, t): return t*t*t*(t*(t*6-15)+10)
    def lerp(self, a, b, t): return a + t*(b-a)

    def grad(self, hash, x, y):
        h = hash & 7
        u = x if h < 4 else y
        v = y if h < 4 else x
        return ((u if (h & 1) == 0 else -u) + (v if (h & 2) == 0 else -v))

    def noise2(self, x, y):
        xi = int(x) & 255
        yi = int(y) & 255
        xf = x - int(x)
        yf = y - int(y)
        u = self.fade(xf)
        v = self.fade(yf)
        aaa = self.p[self.p[xi]+yi]
        aba = self.p[self.p[xi]+yi+1]
        aab = self.p[self.p[xi+1]+yi]
        abb = self.p[self.p[xi+1]+yi+1]
        x1 = self.lerp(self.grad(aaa, xf, yf), self.grad(aab, xf-1, yf), u)
        x2 = self.lerp(self.grad(aba, xf, yf-1), self.grad(abb, xf-1, yf-1), u)
        return (self.lerp(x1, x2, v) + 1.0) / 2.0


noise = PerlinNoise(seed=42)

# ---------- 区块网格构建 ----------


def build_chunk_mesh(blocks_dict, chunk_x, chunk_z):
    vertices = []
    triangles = []
    uvs = []
    normals = []
    colors = []

    block_positions = set(blocks_dict.keys())

    def add_face(v0, v1, v2, v3, normal, block_color):
        idx = len(vertices)
        vertices.extend([v0, v1, v2, v3])
        triangles.extend([idx, idx+1, idx+2, idx, idx+2, idx+3])
        normals.extend([normal]*4)
        uvs.extend([(0, 0), (1, 0), (1, 1), (0, 1)])
        colors.extend([block_color] * 4)

    for (lx, y, lz), block_type in blocks_dict.items():
        world_x = chunk_x * CHUNK_SIZE + lx
        world_z = chunk_z * CHUNK_SIZE + lz
        block_color = BLOCK_TYPES[block_type]

        # 前
        if (lx, y, lz+1) not in block_positions:
            v0 = (world_x,   y,   world_z+1)
            v1 = (world_x+1, y,   world_z+1)
            v2 = (world_x+1, y+1, world_z+1)
            v3 = (world_x,   y+1, world_z+1)
            add_face(v0, v1, v2, v3, (0, 0, 1), block_color)
        # 后
        if (lx, y, lz-1) not in block_positions:
            v0 = (world_x+1, y,   world_z)
            v1 = (world_x,   y,   world_z)
            v2 = (world_x,   y+1, world_z)
            v3 = (world_x+1, y+1, world_z)
            add_face(v0, v1, v2, v3, (0, 0, -1), block_color)
        # 上
        if (lx, y+1, lz) not in block_positions:
            v0 = (world_x,   y+1, world_z)
            v1 = (world_x+1, y+1, world_z)
            v2 = (world_x+1, y+1, world_z+1)
            v3 = (world_x,   y+1, world_z+1)
            add_face(v0, v1, v2, v3, (0, 1, 0), block_color)
        # 下
        if (lx, y-1, lz) not in block_positions:
            v0 = (world_x,   y, world_z)
            v1 = (world_x+1, y, world_z)
            v2 = (world_x+1, y, world_z+1)
            v3 = (world_x,   y, world_z+1)
            add_face(v0, v1, v2, v3, (0, -1, 0), block_color)
        # 右
        if (lx+1, y, lz) not in block_positions:
            v0 = (world_x+1, y,   world_z)
            v1 = (world_x+1, y,   world_z+1)
            v2 = (world_x+1, y+1, world_z+1)
            v3 = (world_x+1, y+1, world_z)
            add_face(v0, v1, v2, v3, (1, 0, 0), block_color)
        # 左
        if (lx-1, y, lz) not in block_positions:
            v0 = (world_x,   y,   world_z+1)
            v1 = (world_x,   y,   world_z)
            v2 = (world_x,   y+1, world_z)
            v3 = (world_x,   y+1, world_z+1)
            add_face(v0, v1, v2, v3, (-1, 0, 0), block_color)

    if vertices:
        mesh = Mesh(vertices=vertices, triangles=triangles,
                    uvs=uvs, normals=normals, colors=colors)
        entity = Entity(model=mesh, collider='mesh', color=color.white)
        return entity
    else:
        return None


def rebuild_chunk(cx, cz):
    if (cx, cz) not in chunks:
        return
    chunk_data = chunks[(cx, cz)]
    entity = build_chunk_mesh(chunk_data['blocks'], cx, cz)
    if entity:
        if chunk_data['entity']:
            destroy(chunk_data['entity'])
        chunk_data['entity'] = entity
    else:
        if chunk_data['entity']:
            destroy(chunk_data['entity'])
            chunk_data['entity'] = None


# ---------- 地形生成 ----------
heightmap = [[0]*WORLD_SIZE for _ in range(WORLD_SIZE)]
chunk_blocks = defaultdict(dict)

generation_queue = []
generation_index = 0
generation_finished = False

progress_bar = None
progress_text = None


def generate_heightmap():
    print("生成高度图中...")
    for x in range(WORLD_SIZE):
        for z in range(WORLD_SIZE):
            nx = x / SCALE
            nz = z / SCALE
            h = noise.noise2(nx, nz) * AMPLITUDE + BASE_HEIGHT
            height = int(max(1, min(WORLD_HEIGHT_LIMIT, h)))
            heightmap[x][z] = height
    print("高度图完成")


def create_blocks_for_chunk(cx, cz):
    start_x = cx * CHUNK_SIZE
    end_x = min(start_x + CHUNK_SIZE, WORLD_SIZE)
    start_z = cz * CHUNK_SIZE
    end_z = min(start_z + CHUNK_SIZE, WORLD_SIZE)
    blocks_dict = {}
    for x in range(start_x, end_x):
        for z in range(start_z, end_z):
            height = heightmap[x][z]
            lx = x - start_x
            lz = z - start_z
            for y in range(height + 1):
                if y == 0:
                    block_type = 'bedrock'
                elif y == height:
                    block_type = 'grass'
                elif y >= height - 3:
                    block_type = 'dirt'
                else:
                    block_type = 'stone'
                blocks_dict[(lx, y, lz)] = block_type
    chunk_blocks[(cx, cz)] = blocks_dict


def add_tree(x, z):
    trunk_height = random.randint(3, 4)
    ground_y = heightmap[x][z]
    if ground_y + trunk_height + 1 >= WORLD_HEIGHT_LIMIT - 2:
        return
    for y in range(ground_y+1, ground_y+trunk_height+1):
        cx = x // CHUNK_SIZE
        cz = z // CHUNK_SIZE
        lx = x - cx*CHUNK_SIZE
        lz = z - cz*CHUNK_SIZE
        if (lx, y, lz) in chunk_blocks[(cx, cz)]:
            return
    for y in range(ground_y+1, ground_y+trunk_height+1):
        cx = x // CHUNK_SIZE
        cz = z // CHUNK_SIZE
        lx = x - cx*CHUNK_SIZE
        lz = z - cz*CHUNK_SIZE
        chunk_blocks[(cx, cz)][(lx, y, lz)] = 'wood'
    leaf_radius = 2
    for dy in range(-leaf_radius, leaf_radius+1):
        for dx in range(-leaf_radius, leaf_radius+1):
            for dz in range(-leaf_radius, leaf_radius+1):
                dist = dx*dx + dy*dy + dz*dz
                if dist <= leaf_radius*leaf_radius:
                    leaf_x = x + dx
                    leaf_y = ground_y + trunk_height + dy
                    leaf_z = z + dz
                    if 0 <= leaf_x < WORLD_SIZE and 0 <= leaf_z < WORLD_SIZE and 0 < leaf_y < WORLD_HEIGHT_LIMIT:
                        if abs(dx) == 0 and abs(dz) == 0 and dy <= trunk_height:
                            continue
                        cx = leaf_x // CHUNK_SIZE
                        cz = leaf_z // CHUNK_SIZE
                        lx = leaf_x - cx*CHUNK_SIZE
                        lz = leaf_z - cz*CHUNK_SIZE
                        if (lx, leaf_y, lz) not in chunk_blocks[(cx, cz)]:
                            chunk_blocks[(cx, cz)][(lx, leaf_y, lz)] = 'leaves'


def add_flower(x, z):
    ground_y = heightmap[x][z]
    y = ground_y + 1
    if y >= WORLD_HEIGHT_LIMIT:
        return
    cx = x // CHUNK_SIZE
    cz = z // CHUNK_SIZE
    lx = x - cx*CHUNK_SIZE
    lz = z - cz*CHUNK_SIZE
    if (lx, ground_y, lz) in chunk_blocks[(cx, cz)] and chunk_blocks[(cx, cz)][(lx, ground_y, lz)] == 'grass':
        if (lx, y, lz) not in chunk_blocks[(cx, cz)]:
            r = random.random()
            if r < 0.05:
                block = random.choice(
                    ['flower_red', 'flower_yellow', 'tall_grass'])
                chunk_blocks[(cx, cz)][(lx, y, lz)] = block


def add_water_pool(x, z):
    ground_y = heightmap[x][z]
    if ground_y < BASE_HEIGHT - 2:
        y = ground_y + 1
        if y >= WORLD_HEIGHT_LIMIT:
            return
        cx = x // CHUNK_SIZE
        cz = z // CHUNK_SIZE
        lx = x - cx*CHUNK_SIZE
        lz = z - cz*CHUNK_SIZE
        if (lx, y, lz) not in chunk_blocks[(cx, cz)]:
            chunk_blocks[(cx, cz)][(lx, y, lz)] = 'water'


def generate_nature():
    print("生成自然景观...")
    spawn_x0 = WORLD_SIZE // 2
    spawn_z0 = WORLD_SIZE // 2
    max_trees_per_chunk = 3
    chunk_tree_count = defaultdict(int)
    surface_points = [(x, z) for x in range(WORLD_SIZE)
                      for z in range(WORLD_SIZE)]
    random.shuffle(surface_points)

    for x, z in surface_points:
        if abs(x - spawn_x0) < 5 and abs(z - spawn_z0) < 5:
            continue
        cx = x // CHUNK_SIZE
        cz = z // CHUNK_SIZE
        if random.random() < 0.005 and chunk_tree_count[(cx, cz)] < max_trees_per_chunk:
            ok = True
            for dx in range(-2, 3):
                for dz in range(-2, 3):
                    nx, nz = x+dx, z+dz
                    if 0 <= nx < WORLD_SIZE and 0 <= nz < WORLD_SIZE:
                        if heightmap[nx][nz] != heightmap[x][z]:
                            ok = False
                            break
                if not ok:
                    break
            if ok:
                add_tree(x, z)
                chunk_tree_count[(cx, cz)] += 1

    for x in range(WORLD_SIZE):
        for z in range(WORLD_SIZE):
            if random.random() < 0.02:
                add_flower(x, z)

    for x in range(WORLD_SIZE):
        for z in range(WORLD_SIZE):
            if random.random() < 0.002:
                add_water_pool(x, z)

    print("自然景观生成完成")

# ---------- 动物类（彻底修复类型错误）----------


class Animal(Entity):
    def __init__(self, animal_type, x, z, ground_y):
        self.animal_type = animal_type
        if animal_type == 'chicken':
            scale = (0.5, 0.5, 0.5)
            animal_color = color.yellow
            base_speed = 0.025
            name_color = color.orange
            self.left_wing = None
            self.right_wing = None
        elif animal_type == 'cow':
            scale = (0.8, 0.8, 0.8)
            animal_color = color.rgb(101, 67, 33)
            base_speed = 0.018
            name_color = color.brown
        else:  # pig
            scale = (0.7, 0.7, 0.7)
            animal_color = color.pink
            base_speed = 0.02
            name_color = color.magenta

        super().__init__(
            model='cube',
            color=animal_color,
            position=(x, ground_y + 0.5, z),
            scale=scale,
            collider='box'
        )
        # 眼睛
        eye = Entity(
            model='cube',
            color=color.white,
            scale=(0.15, 0.15, 0.15),
            position=(0.2, 0.2, 0.45),
            parent=self
        )
        pupil = Entity(
            model='cube',
            color=color.black,
            scale=(0.08, 0.08, 0.08),
            position=(0.25, 0.25, 0.5),
            parent=self
        )
        # 鸡的翅膀
        if animal_type == 'chicken':
            self.left_wing = Entity(
                model='cube',
                color=animal_color,
                scale=(0.3, 0.15, 0.1),
                position=(-0.35, 0.1, 0.3),
                parent=self
            )
            self.right_wing = Entity(
                model='cube',
                color=animal_color,
                scale=(0.3, 0.15, 0.1),
                position=(0.35, 0.1, 0.3),
                parent=self
            )

        self.base_speed = base_speed
        self.speed = base_speed
        self.move_direction = Vec3(
            random.uniform(-1, 1), 0, random.uniform(-1, 1)).normalized()
        self.direction_change_timer = random.uniform(1, 3)
        self.ground_y = ground_y
        self.name_tag = Text(
            text=animal_type.capitalize(),
            position=self.position + (0, 0.7, 0),
            scale=0.5,
            color=name_color,
            origin=(0, 0),
            world=True
        )
        self.walking_animation_time = 0
        self.resting = False
        self.rest_timer = 0
        self.rotation_speed = 5
        # 确保旋转角度是 float 类型
        self.target_rotation_y = float(self.rotation_y)

    def update(self):
        if self.resting:
            self.rest_timer -= time.dt
            if self.rest_timer <= 0:
                self.resting = False
                self.speed = self.base_speed
            else:
                self.update_position_and_animation()
                return

        self.direction_change_timer -= time.dt
        if self.direction_change_timer <= 0:
            if random.random() < 0.3:
                self.resting = True
                self.rest_timer = random.uniform(1.5, 3)
                self.speed = 0
            else:
                new_dir = Vec3(random.uniform(-1, 1), 0,
                               random.uniform(-1, 1)).normalized()
                if new_dir.dot(self.move_direction) < -0.5:
                    new_dir = -new_dir
                self.move_direction = new_dir
                self.direction_change_timer = random.uniform(1.5, 4)

        new_x = self.x + self.move_direction.x * self.speed
        new_z = self.z + self.move_direction.z * self.speed

        if new_x < 0.5 or new_x >= WORLD_SIZE - 0.5 or new_z < 0.5 or new_z >= WORLD_SIZE - 0.5:
            self.move_direction = -self.move_direction
            return

        ground_y = heightmap[int(new_x)][int(new_z)]
        if abs(ground_y - self.ground_y) > 1.0:
            self.move_direction = Vec3(
                random.uniform(-1, 1), 0, random.uniform(-1, 1)).normalized()
            return

        check_x = int(self.x + self.move_direction.x * 0.6)
        check_z = int(self.z + self.move_direction.z * 0.6)
        if 0 <= check_x < WORLD_SIZE and 0 <= check_z < WORLD_SIZE:
            y_check = int(self.ground_y + 1)
            cx = check_x // CHUNK_SIZE
            cz = check_z // CHUNK_SIZE
            lx = check_x - cx*CHUNK_SIZE
            lz = check_z - cz*CHUNK_SIZE
            if (cx, cz) in chunks and (lx, y_check, lz) in chunks[(cx, cz)]['blocks']:
                block = chunks[(cx, cz)]['blocks'][(lx, y_check, lz)]
                if block not in ('grass', 'dirt', 'tall_grass', 'flower_red', 'flower_yellow', 'water'):
                    self.move_direction = Vec3(
                        random.uniform(-1, 1), 0, random.uniform(-1, 1)).normalized()
                    return

        self.x = new_x
        self.z = new_z
        self.ground_y = ground_y
        self.y = ground_y + 0.5

        # 平滑旋转 - 强制使用 float
        if self.move_direction.length() > 0.01:
            angle = math.degrees(math.atan2(
                self.move_direction.x, self.move_direction.z))
            self.target_rotation_y = float(angle)
            current_rot = float(self.rotation_y)
            target = self.target_rotation_y
            diff = target - current_rot
            if diff > 180:
                diff -= 360
            if diff < -180:
                diff += 360
            new_rot = current_rot + diff * self.rotation_speed * time.dt
            self.rotation_y = float(new_rot)

        self.update_position_and_animation()

    def update_position_and_animation(self):
        if not self.resting and self.speed > 0:
            self.walking_animation_time += time.dt * 12
            y_offset = math.sin(self.walking_animation_time) * 0.03
            self.y = self.ground_y + 0.5 + y_offset
            if self.animal_type == 'chicken' and self.left_wing and self.right_wing:
                wing_angle = math.sin(self.walking_animation_time * 8) * 0.8
                self.left_wing.rotation_z = wing_angle * 30
                self.right_wing.rotation_z = -wing_angle * 30
        else:
            self.y = self.ground_y + 0.5
            if self.animal_type == 'chicken' and self.left_wing and self.right_wing:
                self.left_wing.rotation_z = 0
                self.right_wing.rotation_z = 0
        # 更新名字标签位置
        if self.name_tag:
            self.name_tag.position = self.position + (0, 0.7, 0)

    def on_destroy(self):
        if self.name_tag:
            destroy(self.name_tag)
        if self.left_wing:
            destroy(self.left_wing)
        if self.right_wing:
            destroy(self.right_wing)


def spawn_animals():
    print("生成动物...")
    spawn_positions = []
    for x in range(WORLD_SIZE):
        for z in range(WORLD_SIZE):
            ground_y = heightmap[x][z]
            cx = x // CHUNK_SIZE
            cz = z // CHUNK_SIZE
            lx = x - cx*CHUNK_SIZE
            lz = z - cz*CHUNK_SIZE
            if (cx, cz) in chunks and (lx, ground_y, lz) in chunks[(cx, cz)]['blocks']:
                if chunks[(cx, cz)]['blocks'][(lx, ground_y, lz)] == 'grass':
                    flat = True
                    for dx in range(-1, 2):
                        for dz in range(-1, 2):
                            nx, nz = x+dx, z+dz
                            if 0 <= nx < WORLD_SIZE and 0 <= nz < WORLD_SIZE:
                                if abs(heightmap[nx][nz] - ground_y) > 1:
                                    flat = False
                                    break
                        if not flat:
                            break
                    if flat:
                        spawn_positions.append((x, z, ground_y))

    max_animals = 150
    random.shuffle(spawn_positions)
    for i, (x, z, ground_y) in enumerate(spawn_positions):
        if i >= max_animals:
            break
        animal_type = random.choice(['chicken', 'cow', 'pig'])
        animal = Animal(animal_type, x, z, ground_y)
        animals.append(animal)
    print(f"生成了 {len(animals)} 只动物")

# ---------- 生成流程 ----------


def generate_next_chunk():
    global generation_index, generation_finished, progress_text, progress_bar, spawn_point
    if generation_index < len(generation_queue):
        cx, cz = generation_queue[generation_index]
        if (cx, cz) not in chunks:
            if (cx, cz) not in chunk_blocks:
                create_blocks_for_chunk(cx, cz)
            blocks_dict = chunk_blocks[(cx, cz)]
            entity = build_chunk_mesh(blocks_dict, cx, cz)
            chunks[(cx, cz)] = {
                'entity': entity,
                'blocks': blocks_dict
            }
        generation_index += 1
        if progress_text:
            progress_text.text = f"生成地形 {generation_index}/{len(generation_queue)} 区块"
        if generation_index == len(generation_queue):
            generation_finished = True
            if progress_text:
                progress_text.text = "生成完成！"
            if progress_bar:
                destroy(progress_bar)
            invoke(lambda: setattr(progress_text, 'enabled', False), delay=2)

            # 安全出生点扫描
            center_x = WORLD_SIZE // 2
            center_z = WORLD_SIZE // 2
            safe_spawn = None
            search_radius = 20
            for dx in range(-search_radius, search_radius+1):
                for dz in range(-search_radius, search_radius+1):
                    x = center_x + dx
                    z = center_z + dz
                    if 0 <= x < WORLD_SIZE and 0 <= z < WORLD_SIZE:
                        for y in range(WORLD_HEIGHT_LIMIT, 0, -1):
                            cx = x // CHUNK_SIZE
                            cz = z // CHUNK_SIZE
                            lx = x - cx*CHUNK_SIZE
                            lz = z - cz*CHUNK_SIZE
                            if (lx, y, lz) in chunks[(cx, cz)]['blocks']:
                                block = chunks[(cx, cz)]['blocks'][(lx, y, lz)]
                                if block in ('grass', 'dirt', 'stone'):
                                    if (lx, y+1, lz) not in chunks[(cx, cz)]['blocks'] and (lx, y+2, lz) not in chunks[(cx, cz)]['blocks']:
                                        safe_spawn = (x, y+1.5, z)
                                        break
                        if safe_spawn:
                            break
                if safe_spawn:
                    break
            if not safe_spawn:
                max_h = 0
                best_x, best_z = center_x, center_z
                for x in range(WORLD_SIZE):
                    for z in range(WORLD_SIZE):
                        h = heightmap[x][z]
                        if h > max_h:
                            max_h = h
                            best_x, best_z = x, z
                safe_spawn = (best_x, max_h+1.5, best_z)

            spawn_point = safe_spawn
            player.position = spawn_point
            player.enabled = True
            mouse.locked = True
            print(f"生成完成！安全出生点: {spawn_point}")

            spawn_animals()
        return True
    return False


def start_world_generation():
    global generation_queue, progress_bar, progress_text, generation_finished
    generate_heightmap()

    num_chunks_x = (WORLD_SIZE + CHUNK_SIZE - 1) // CHUNK_SIZE
    num_chunks_z = (WORLD_SIZE + CHUNK_SIZE - 1) // CHUNK_SIZE
    generation_queue = [(cx, cz) for cx in range(num_chunks_x)
                        for cz in range(num_chunks_z)]
    print("预生成基础地形数据...")
    total_chunks = len(generation_queue)
    for idx, (cx, cz) in enumerate(generation_queue):
        if (cx, cz) not in chunk_blocks:
            create_blocks_for_chunk(cx, cz)
        if idx % 20 == 0:
            print(f"预处理 {idx+1}/{total_chunks}")

    generate_nature()

    progress_bar = Entity(model='quad', scale=(
        0.3, 0.05), color=color.azure, position=(0, -0.4), parent=camera.ui)
    progress_text = Text(f"生成地形 0/{total_chunks} 区块", position=(
        0, -0.35), origin=(0, 0), parent=camera.ui, scale=1.5)
    generation_finished = False

# ---------- 挖掘与放置 ----------


def dig():
    if not (mouse.hovered_entity and mouse.hovered_entity in [chunk['entity'] for chunk in chunks.values() if chunk['entity']]):
        return
    if mouse.point is None or mouse.normal is None:
        return
    point = mouse.point
    normal = mouse.normal
    bx = int(math.floor(point[0] - normal[0] * 0.5))
    by = int(math.floor(point[1] - normal[1] * 0.5))
    bz = int(math.floor(point[2] - normal[2] * 0.5))
    if not (0 <= bx < WORLD_SIZE and 0 <= bz < WORLD_SIZE and 0 <= by <= WORLD_HEIGHT_LIMIT):
        return
    cx = bx // CHUNK_SIZE
    cz = bz // CHUNK_SIZE
    if (cx, cz) not in chunks:
        return
    lx = bx - cx * CHUNK_SIZE
    lz = bz - cz * CHUNK_SIZE
    if (lx, by, lz) not in chunks[(cx, cz)]['blocks']:
        return
    del chunks[(cx, cz)]['blocks'][(lx, by, lz)]
    rebuild_chunk(cx, cz)
    for dx, dz in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        nx, nz = cx+dx, cz+dz
        if (nx, nz) in chunks:
            rebuild_chunk(nx, nz)
    print(f"挖掘了 ({bx},{by},{bz})")


def place_block():
    if not (mouse.hovered_entity and mouse.hovered_entity in [chunk['entity'] for chunk in chunks.values() if chunk['entity']]):
        return
    if mouse.point is None or mouse.normal is None:
        return
    point = mouse.point
    normal = mouse.normal
    bx = int(math.floor(point[0] - normal[0] * 0.5))
    by = int(math.floor(point[1] - normal[1] * 0.5))
    bz = int(math.floor(point[2] - normal[2] * 0.5))
    px = bx + int(round(normal[0]))
    py = by + int(round(normal[1]))
    pz = bz + int(round(normal[2]))
    if not (0 <= px < WORLD_SIZE and 0 <= pz < WORLD_SIZE and 0 <= py <= WORLD_HEIGHT_LIMIT):
        return
    cx = px // CHUNK_SIZE
    cz = pz // CHUNK_SIZE
    if (cx, cz) not in chunks:
        return
    lx = px - cx * CHUNK_SIZE
    lz = pz - cz * CHUNK_SIZE
    if (lx, py, lz) in chunks[(cx, cz)]['blocks']:
        return
    chunks[(cx, cz)]['blocks'][(lx, py, lz)] = current_block_type
    rebuild_chunk(cx, cz)
    for dx, dz in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        nx, nz = cx+dx, cz+dz
        if (nx, nz) in chunks:
            rebuild_chunk(nx, nz)
    print(f"放置了 {current_block_type} 于 ({px},{py},{pz})")

# ---------- 方块切换 ----------


def switch_to_grass(): global current_block_type; current_block_type = 'grass'; print("切换到: 草")
def switch_to_dirt(): global current_block_type; current_block_type = 'dirt'; print("切换到: 泥土")
def switch_to_stone(): global current_block_type; current_block_type = 'stone'; print("切换到: 石头")
def switch_to_bedrock(
): global current_block_type


current_block_type = 'bedrock'
print("切换到: 基岩")
def switch_to_wood(): global current_block_type; current_block_type = 'wood'; print("切换到: 木头")
def switch_to_leaves(): global current_block_type; current_block_type = 'leaves'; print("切换到: 树叶")
def switch_to_water(): global current_block_type; current_block_type = 'water'; print("切换到: 水")

# ---------- 输入 ----------


def input(key):
    if key == 'escape':
        mouse.locked = not mouse.locked
    if key == 'left mouse down':
        dig()
    if key == 'right mouse down':
        place_block()
    if key == '1':
        switch_to_grass()
    if key == '2':
        switch_to_dirt()
    if key == '3':
        switch_to_stone()
    if key == '4':
        switch_to_bedrock()
    if key == '5':
        switch_to_wood()
    if key == '6':
        switch_to_leaves()
    if key == '7':
        switch_to_water()
    if key == 'space':
        player.jump()


# ---------- 玩家与UI ----------
player = FirstPersonController(
    position=(WORLD_SIZE//2, 10, WORLD_SIZE//2), enabled=False)
Sky()
DirectionalLight()

status_text = Text("", position=(-0.8, 0.4), scale=1.0, background=True)


def update_ui():
    status_text.text = f"""方块: {current_block_type}
位置: ({player.x:.1f}, {player.y:.1f}, {player.z:.1f})
左键:挖掘 | 右键:放置 | 空格:跳跃
1草 2泥土 3石头 4基岩 5木头 6树叶 7水
动物: {len(animals)}只 | 世界: {WORLD_SIZE}x{WORLD_SIZE} | 区块: {len(chunks)}"""


def update():
    global spawn_point
    if not generation_finished:
        generate_next_chunk()
    else:
        for animal in animals:
            if animal:
                animal.update()
        if player.y < -100:
            player.position = spawn_point
            player.velocity = Vec3(0, 0, 0)
            print("坠落保护：已传送回出生点")
    update_ui()


start_world_generation()

print("=== PocketWorld 动物版 + 模组支持 ===")
print("自动加载 C:/Pocket World/mode 和 D:/Pocket World/mode 中的 .py 文件")
print("按键: 1-7 切换方块，左键挖掘，右键放置，空格跳跃，Escape锁定鼠标")

app.run()
