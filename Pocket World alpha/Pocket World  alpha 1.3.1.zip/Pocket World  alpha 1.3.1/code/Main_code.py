import os
import sys
import pickle
import importlib.util
import math
import random
from pathlib import Path
from collections import defaultdict
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

# ---------- 资源路径辅助（兼容打包） ----------


def resource_path(relative_path):
    """获取资源的绝对路径，兼容开发环境和打包后的 exe"""
    try:
        # PyInstaller / Nuitka 打包后，资源会解压到 sys._MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


# ---------- 定义透明颜色 ----------
TRANSPARENT = color.rgba(0, 0, 0, 0)

# ---------- 动态加载外部 mod ----------


def get_mode_dirs():
    # 优先使用 exe 同级目录下的 mode 文件夹
    base = resource_path("")
    return [
        Path(os.path.join(base, "mode")),
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.3.1/mode"),
        Path("D:/Pocket World alpha 1.3.1/mode")
    ]


def load_mods():
    for mod_path in get_mode_dirs():
        if not mod_path.exists() or not mod_path.is_dir():
            continue
        print(f"发现 mod 目录: {mod_path}")
        for py_file in mod_path.glob("*.py"):
            try:
                module_name = py_file.stem
                spec = importlib.util.spec_from_file_location(
                    module_name, py_file)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)
                    print(f"  已加载 mod: {module_name}")
            except Exception as e:
                print(f"  加载 {py_file.name} 失败: {e}")
        break


load_mods()

# ---------- 存档路径 ----------


def get_save_dir():
    # 优先使用 exe 同级目录下的 saves
    base = os.getcwd() if getattr(
        sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
    candidates = [
        Path(os.path.join(base, "saves")),
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.3.1/saves"),
        Path("D:/Pocket World alpha 1.3.1/saves")
    ]
    for p in candidates:
        if p.exists():
            return p
    # 都不存在则创建当前目录下的 saves
    saves_dir = Path(os.path.join(base, "saves"))
    saves_dir.mkdir(parents=True, exist_ok=True)
    return saves_dir


SAVE_DIR = get_save_dir()
WORLD_FILE = SAVE_DIR / "world.dat"
print(f"存档目录: {SAVE_DIR}")

# ---------- 游戏主程序 ----------
app = Ursina()
window.title = 'PocketWorld Infinite (内置天空版)'
Text.default_font = '微软雅黑'

# ---------- 生存模式、物品栏、背包 ----------
player_health = 20
max_health = 20
player_hunger = 20
max_hunger = 20
inventory = [(None, 0)] * 9
backpack = [(None, 0)] * 36
current_hotbar_slot = 0
backpack_open = False

BLOCK_ITEMS = {
    'grass': '草方块', 'dirt': '泥土', 'stone': '石头',
    'bedrock': '基岩', 'wood': '木头', 'leaves': '树叶', 'water': '水',
    'rotten_meat': '腐肉', 'bone': '骨头', 'cooked_chicken': '熟鸡肉',
}

FOOD_ITEMS = {
    'cooked_chicken': 6,
    'rotten_meat': 2,
}

inventory[0] = ('grass', 10)
inventory[1] = ('dirt', 10)
inventory[2] = ('stone', 5)
inventory[3] = ('wood', 5)
backpack[0] = ('grass', 20)

# ---------- 游戏参数 ----------
CHUNK_SIZE = 16
RENDER_RADIUS = 1
WORLD_HEIGHT_LIMIT = 64
BASE_HEIGHT = 8
AMPLITUDE = 4
SCALE = 80.0

BLOCK_COLORS = {
    'grass': color.rgb(87, 127, 47),
    'dirt': color.rgb(98, 67, 28),
    'stone': color.rgb(127, 127, 127),
    'bedrock': color.rgb(50, 50, 50),
    'wood': color.rgb(139, 69, 19),
    'leaves': color.rgb(34, 139, 34),
    'water': color.rgb(64, 164, 223, 180),
    'rotten_meat': color.rgb(100, 70, 30),
    'bone': color.rgb(220, 220, 200),
    'cooked_chicken': color.rgb(200, 150, 80),
}
current_block_type = 'grass'

# ---------- 昼夜系统 ----------
game_time = 360.0   # 6:00

# ---------- 天气系统 ----------
is_raining = False
rain_remain = 0.0
rain_chance = 1 / 20
rain_base_duration = 5 * 60

# ---------- 怪物系统 ----------
monsters = []
monster_spawn_timer = 0.0
monster_spawn_interval = 5.0

# ---------- 实体纹理映射 ----------
ENTITY_TEXTURES = {
    'chicken': 'chicken',
    'cow': 'cow',
    'pig': 'pig',
    'zombie': 'zombie',
    'skeleton': 'skeleton',
}

# ---------- 创建贴图实体（交叉平面） ----------


def create_textured_entity(texture, scale=1.0, color=color.white):
    group = Entity()
    plane1 = Entity(
        model='quad',
        texture=texture,
        color=color,
        scale=(scale, scale, 1),
        rotation=(0, 0, 0),
        double_sided=True,
        parent=group
    )
    plane2 = Entity(
        model='quad',
        texture=texture,
        color=color,
        scale=(scale, scale, 1),
        rotation=(0, 90, 0),
        double_sided=True,
        parent=group
    )
    collider = Entity(
        model='cube',
        scale=(scale*0.8, scale*0.8, scale*0.8),
        color=TRANSPARENT,
        collider='box',
        parent=group
    )
    group.children = [plane1, plane2, collider]
    group.collider_entity = collider
    return group

# ---------- 动物类 ----------


class Animal(Entity):
    def __init__(self, animal_type, x, z, ground_y):
        super().__init__(position=(x, ground_y + 0.5, z))
        self.animal_type = animal_type
        tex_name = ENTITY_TEXTURES.get(animal_type, 'chicken')
        tex = block_textures.get(tex_name)
        if animal_type == 'chicken':
            scale = 0.6
            speed = 0.025
            name_color = color.orange
        elif animal_type == 'cow':
            scale = 0.8
            speed = 0.018
            name_color = color.brown
        else:
            scale = 0.7
            speed = 0.02
            name_color = color.magenta

        self.vis_group = create_textured_entity(
            tex, scale=scale, color=color.white)
        self.vis_group.parent = self
        self.vis_group.position = (0, 0, 0)

        self.speed = speed
        self.move_dir = Vec3(random.uniform(-1, 1), 0,
                             random.uniform(-1, 1)).normalized()
        self.dir_timer = random.uniform(1, 3)
        self.ground_y = ground_y
        self.name_tag = Text(text=animal_type.capitalize(),
                             position=self.position + (0, scale*0.7 + 0.3, 0),
                             scale=0.5, color=name_color, origin=(0, 0), world=True)
        self.walk_time = 0

    def update(self):
        self.dir_timer -= time.dt
        if self.dir_timer <= 0:
            self.move_dir = Vec3(random.uniform(-1, 1), 0,
                                 random.uniform(-1, 1)).normalized()
            self.dir_timer = random.uniform(1, 3)
        new_x = self.x + self.move_dir.x * self.speed
        new_z = self.z + self.move_dir.z * self.speed
        if not (-1000 < new_x < 1000 and -1000 < new_z < 1000):
            self.move_dir = -self.move_dir
            return
        ground = get_height(int(new_x), int(new_z))
        if abs(ground - self.ground_y) > 1.5:
            self.move_dir = Vec3(random.uniform(-1, 1), 0,
                                 random.uniform(-1, 1)).normalized()
            return
        self.x = new_x
        self.z = new_z
        self.ground_y = ground
        self.y = ground + 0.5 + math.sin(self.walk_time) * 0.03
        self.walk_time += time.dt * 12
        self.name_tag.position = self.position + (0, 0.6, 0)

    def destroy(self):
        destroy(self)

# ---------- 怪物基类 ----------


class Monster(Entity):
    def __init__(self, position, tex_name, health, speed, attack_damage, attack_range=2.0):
        super().__init__(position=position)
        tex = block_textures.get(tex_name)
        self.vis_group = create_textured_entity(
            tex, scale=0.8, color=color.white)
        self.vis_group.parent = self
        self.vis_group.position = (0, 0, 0)

        self.health = health
        self.max_health = health
        self.speed = speed
        self.attack_damage = attack_damage
        self.attack_range = attack_range
        self.attack_cooldown = 0.0
        self.target = player
        self._dead = False

    def take_damage(self, amount):
        if self._dead:
            return
        self.health -= amount
        if self.health <= 0:
            self._dead = True
            self.on_death()
            self.destroy()
            if self in monsters:
                monsters.remove(self)

    def on_death(self):
        pass

    def update(self):
        if self._dead or self.target is None:
            return
        distance_to_target = distance(self.position, self.target.position)
        if distance_to_target < self.attack_range:
            if self.attack_cooldown <= 0:
                self.attack()
                self.attack_cooldown = 1.0
            self.attack_cooldown -= time.dt
            return
        direction = (self.target.position - self.position).normalized()
        self.position += direction * self.speed * time.dt

    def attack(self):
        global player_health
        player_health -= self.attack_damage
        print(f"{self.__class__.__name__}攻击！生命值: {player_health}")

    def destroy(self):
        if self._dead:
            return
        self._dead = True
        destroy(self)

# ---------- 具体怪物 ----------


class Zombie(Monster):
    def __init__(self, position):
        super().__init__(position, 'zombie', health=10,
                         speed=1.0, attack_damage=2, attack_range=2.0)

    def on_death(self):
        add_to_backpack('rotten_meat')
        print("僵尸被击败！掉落腐肉")


class Skeleton(Monster):
    def __init__(self, position):
        super().__init__(position, 'skeleton', health=8,
                         speed=0.8, attack_damage=1, attack_range=8.0)
        self.shoot_cooldown = 0.0

    def attack(self):
        global player_health
        player_health -= self.attack_damage
        print(f"骷髅射击！生命值: {player_health}")

    def on_death(self):
        add_to_backpack('bone')
        print("骷髅被击败！掉落骨头")

    def update(self):
        if self._dead or self.target is None:
            return
        distance_to_target = distance(self.position, self.target.position)
        if distance_to_target < 8.0:
            direction = (self.position - self.target.position).normalized()
            self.position += direction * self.speed * time.dt
        self.shoot_cooldown -= time.dt
        if self.shoot_cooldown <= 0 and distance_to_target < 15.0:
            self.attack()
            self.shoot_cooldown = 1.5


# ---------- 核心数据结构 ----------
chunks = {}
animals = []
loaded_chunks = set()
flower_entities = []

# ---------- UI 元素 ----------
crosshair = Entity(model='quad', scale=(0.02, 0.02), parent=camera.ui,
                   texture='white_cube', color=color.white)

health_bg = Entity(model='quad', color=color.rgb(50, 50, 50), position=(-0.7, 0.45),
                   scale=(0.3, 0.04), parent=camera.ui)
health_bar = Entity(model='quad', color=color.red, position=(-0.7, 0.45),
                    scale=(0.3, 0.04), parent=camera.ui)
health_text = Text('20/20', position=(-0.7, 0.48), scale=1, parent=camera.ui)

hunger_bg = Entity(model='quad', color=color.rgb(50, 50, 50), position=(-0.7, 0.41),
                   scale=(0.3, 0.03), parent=camera.ui)
hunger_bar = Entity(model='quad', color=color.rgb(0, 200, 50), position=(-0.7, 0.41),
                    scale=(0.3, 0.03), parent=camera.ui)
hunger_text = Text('20/20', position=(-0.7, 0.44), scale=0.8,
                   parent=camera.ui, color=color.lime)

hotbar_bg = Entity(model='quad', color=color.rgb(30, 30, 30, 150), position=(0, -0.42),
                   scale=(0.6, 0.08), parent=camera.ui)
hotbar_slots = []
hotbar_icons = []
hotbar_counts = []
for i in range(9):
    slot = Entity(model='quad', color=color.rgb(80, 80, 80),
                  position=(-0.27 + i*0.075, -0.42), scale=(0.065, 0.065), parent=camera.ui)
    hotbar_slots.append(slot)
    icon = Entity(model='quad', position=(-0.27 + i*0.075, -0.42), scale=(0.055, 0.055),
                  parent=camera.ui, texture=None, color=color.white)
    hotbar_icons.append(icon)
    count = Text('', position=(-0.24 + i*0.075, -0.445), scale=0.5, color=color.white,
                 parent=camera.ui, background=True)
    hotbar_counts.append(count)

backpack_bg = Entity(model='quad', color=color.rgb(20, 20, 40, 200), position=(0, 0),
                     scale=(0.8, 0.8), parent=camera.ui, enabled=False)
backpack_title = Text('背包 (按E关闭)', position=(-0.7, 0.65),
                      scale=1.5, parent=camera.ui, enabled=False)
backpack_slots = []
backpack_icons = []
backpack_counts = []
for row in range(4):
    for col in range(9):
        slot = Entity(model='quad', color=color.rgb(80, 80, 80),
                      position=(-0.35 + col*0.075, 0.4 - row*0.12), scale=(0.055, 0.055),
                      parent=camera.ui, enabled=False)
        backpack_slots.append(slot)
        icon = Entity(model='quad', position=(-0.35 + col*0.075, 0.4 - row*0.12),
                      scale=(0.045, 0.045), parent=camera.ui, texture=None,
                      color=color.white, enabled=False)
        backpack_icons.append(icon)
        count = Text('', position=(-0.32 + col*0.075, 0.375 - row*0.12), scale=0.4,
                     color=color.white, parent=camera.ui, enabled=False, background=True)
        backpack_counts.append(count)

# ---------- UI 更新函数 ----------


def update_hotbar_ui():
    for i, slot in enumerate(hotbar_slots):
        slot.color = color.rgb(
            200, 200, 100) if i == current_hotbar_slot else color.rgb(80, 80, 80)
    for i in range(9):
        item_type, quantity = inventory[i] if i < len(inventory) else (None, 0)
        if item_type and quantity > 0:
            tex = block_textures.get(item_type)
            hotbar_icons[i].texture = tex
            hotbar_icons[i].color = color.white if tex else BLOCK_COLORS.get(
                item_type, color.gray)
            hotbar_counts[i].text = f'x{quantity}' if quantity > 1 else ''
        else:
            hotbar_icons[i].texture = None
            hotbar_icons[i].color = TRANSPARENT
            hotbar_counts[i].text = ''


def update_backpack_ui():
    for i in range(36):
        item_type, quantity = backpack[i] if i < len(backpack) else (None, 0)
        if item_type and quantity > 0:
            tex = block_textures.get(item_type)
            backpack_icons[i].texture = tex
            backpack_icons[i].color = color.white if tex else BLOCK_COLORS.get(
                item_type, color.gray)
            backpack_counts[i].text = f'x{quantity}' if quantity > 1 else ''
        else:
            backpack_icons[i].texture = None
            backpack_icons[i].color = TRANSPARENT
            backpack_counts[i].text = ''

# ---------- 加载纹理 ----------


def load_textures():
    textures = {}
    # 优先使用 resource_path 获取 modeling 目录
    modeling_dir = Path(resource_path("modeling"))
    paths = [
        modeling_dir,
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.3.1/modeling"),
        Path("D:/Pocket World alpha 1.3.1/modeling")
    ]
    name_map = {
        'grass': 'grass', 'dirt': 'dirt', 'stone': 'stone', 'bedrock': 'Bedrock',
        'wood': 'wood', 'leaves': 'Leaf', 'water': 'water', 'flower': 'flower',
        'rotten_meat': 'rotten_meat', 'bone': 'bone', 'cooked_chicken': 'cooked_chicken',
        'chicken': 'chicken', 'cow': 'cow', 'pig': 'pig',
        'zombie': 'zombie', 'skeleton': 'skeleton',
    }
    for path in paths:
        if not path.exists():
            continue
        for key, filename in name_map.items():
            img_path = path / (filename + '.png')
            if img_path.exists():
                try:
                    tex = Texture(str(img_path))
                    textures[key] = tex
                    print(f"加载纹理: {key} -> {img_path}")
                except Exception as e:
                    print(f"加载纹理 {img_path} 失败: {e}")
        break
    return textures


block_textures = load_textures()

# ---------- Perlin 噪声 ----------


class PerlinNoise:
    def __init__(self, seed=42):
        random.seed(seed)
        self.p = list(range(256))
        random.shuffle(self.p)
        self.p += self.p

    def fade(self, t): return t*t*t*(t*(t*6-15)+10)
    def lerp(self, a, b, t): return a + t*(b-a)

    def grad(self, hash, x, y):
        h = hash & 7
        u = x if h < 4 else y
        v = y if h < 4 else x
        return ((u if (h & 1) == 0 else -u) + (v if (h & 2) == 0 else -v))

    def noise2(self, x, y):
        xi = int(x) & 255
        yi = int(y) & 255
        xf = x - int(x)
        yf = y - int(y)
        u = self.fade(xf)
        v = self.fade(yf)
        aaa = self.p[self.p[xi]+yi]
        aba = self.p[self.p[xi]+yi+1]
        aab = self.p[self.p[xi+1]+yi]
        abb = self.p[self.p[xi+1]+yi+1]
        x1 = self.lerp(self.grad(aaa, xf, yf), self.grad(aab, xf-1, yf), u)
        x2 = self.lerp(self.grad(aba, xf, yf-1), self.grad(abb, xf-1, yf-1), u)
        return (self.lerp(x1, x2, v) + 1.0) / 2.0


noise = PerlinNoise(seed=42)


def get_height(x, z):
    nx = x / SCALE
    nz = z / SCALE
    h = noise.noise2(nx, nz) * AMPLITUDE + BASE_HEIGHT
    return int(max(1, min(WORLD_HEIGHT_LIMIT, h)))


def has_block_at(wx, wy, wz):
    cx = wx // CHUNK_SIZE
    cy = wy // CHUNK_SIZE
    cz = wz // CHUNK_SIZE
    key = (cx, cy, cz)
    if key not in chunks:
        return False
    lx = wx - cx * CHUNK_SIZE
    ly = wy - cy * CHUNK_SIZE
    lz = wz - cz * CHUNK_SIZE
    return (lx, ly, lz) in chunks[key]['blocks']


def build_chunk_mesh_for_type(block_positions, btype, cx, cy, cz):
    vertices = []
    triangles = []
    uvs = []
    normals = []
    colors = []
    base_x = cx * CHUNK_SIZE
    base_y = cy * CHUNK_SIZE
    base_z = cz * CHUNK_SIZE
    tex = block_textures.get(btype)
    use_texture = tex is not None
    block_color = BLOCK_COLORS.get(btype, color.gray)
    std_uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]

    def add_face(v0, v1, v2, v3, normal):
        idx = len(vertices)
        vertices.extend([v0, v1, v2, v3])
        triangles.extend([idx, idx+1, idx+2, idx, idx+2, idx+3])
        normals.extend([normal]*4)
        if use_texture:
            uvs.extend(std_uvs)
        else:
            colors.extend([block_color]*4)
            uvs.extend([(0, 0), (0, 0), (0, 0), (0, 0)])

    for (lx, ly, lz) in block_positions:
        world_x = base_x + lx
        world_y = base_y + ly
        world_z = base_z + lz
        if not has_block_at(world_x+1, world_y, world_z):
            v0 = (world_x+1, world_y,   world_z)
            v1 = (world_x+1, world_y,   world_z+1)
            v2 = (world_x+1, world_y+1, world_z+1)
            v3 = (world_x+1, world_y+1, world_z)
            add_face(v0, v1, v2, v3, (1, 0, 0))
        if not has_block_at(world_x-1, world_y, world_z):
            v0 = (world_x,   world_y,   world_z+1)
            v1 = (world_x,   world_y,   world_z)
            v2 = (world_x,   world_y+1, world_z)
            v3 = (world_x,   world_y+1, world_z+1)
            add_face(v0, v1, v2, v3, (-1, 0, 0))
        if not has_block_at(world_x, world_y+1, world_z):
            v0 = (world_x,   world_y+1, world_z)
            v1 = (world_x+1, world_y+1, world_z)
            v2 = (world_x+1, world_y+1, world_z+1)
            v3 = (world_x,   world_y+1, world_z+1)
            add_face(v0, v1, v2, v3, (0, 1, 0))
        if not has_block_at(world_x, world_y-1, world_z):
            v0 = (world_x,   world_y, world_z)
            v1 = (world_x+1, world_y, world_z)
            v2 = (world_x+1, world_y, world_z+1)
            v3 = (world_x,   world_y, world_z+1)
            add_face(v0, v1, v2, v3, (0, -1, 0))
        if not has_block_at(world_x, world_y, world_z+1):
            v0 = (world_x,   world_y,   world_z+1)
            v1 = (world_x+1, world_y,   world_z+1)
            v2 = (world_x+1, world_y+1, world_z+1)
            v3 = (world_x,   world_y+1, world_z+1)
            add_face(v0, v1, v2, v3, (0, 0, 1))
        if not has_block_at(world_x, world_y, world_z-1):
            v0 = (world_x+1, world_y,   world_z)
            v1 = (world_x,   world_y,   world_z)
            v2 = (world_x,   world_y+1, world_z)
            v3 = (world_x+1, world_y+1, world_z)
            add_face(v0, v1, v2, v3, (0, 0, -1))
    if vertices:
        mesh = Mesh(vertices=vertices, triangles=triangles,
                    uvs=uvs, normals=normals)
        if use_texture:
            entity = Entity(model=mesh, texture=tex,
                            color=color.white, collider='mesh')
        else:
            entity = Entity(model=mesh, color=block_color, collider='mesh')
        return entity
    else:
        return None


def rebuild_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    chunk_data = chunks[key]
    if 'entities' in chunk_data:
        for ent in chunk_data['entities'].values():
            if ent:
                destroy(ent)
    chunk_data['entities'] = {}
    type_blocks = defaultdict(list)
    for (lx, ly, lz), btype in chunk_data['blocks'].items():
        type_blocks[btype].append((lx, ly, lz))
    for btype, pos_list in type_blocks.items():
        entity = build_chunk_mesh_for_type(pos_list, btype, cx, cy, cz)
        if entity:
            chunk_data['entities'][btype] = entity

# ---------- 花 ----------


class FlowerEntity(Entity):
    def __init__(self, position, texture=None, flower_color=color.white, **kwargs):
        self.plane1 = Entity(model='quad', texture=texture, color=flower_color,
                             position=position, scale=(0.5, 0.5, 0.5), rotation=(0, 0, 0), double_sided=True)
        self.plane2 = Entity(model='quad', texture=texture, color=flower_color,
                             position=position, scale=(0.5, 0.5, 0.5), rotation=(0, 90, 0), double_sided=True)
        angle = random.uniform(0, 360)
        self.plane1.rotation_y = angle
        self.plane2.rotation_y = angle + 90
        self.children = [self.plane1, self.plane2]
        super().__init__(position=position, **kwargs)

    def destroy(self):
        for child in self.children:
            destroy(child)
        destroy(self)


def create_flower_entity(x, y, z, tex, flower_color=color.white):
    flower_group = Entity()
    plane1 = Entity(model='quad', texture=tex, color=flower_color,
                    position=(x, y, z), scale=(0.5, 0.5, 0.5), rotation=(0, random.uniform(0, 360), 0),
                    double_sided=True, parent=flower_group)
    plane2 = Entity(model='quad', texture=tex, color=flower_color,
                    position=(x, y, z), scale=(0.5, 0.5, 0.5), rotation=(0, random.uniform(0, 360)+90, 0),
                    double_sided=True, parent=flower_group)
    flower_group.children = [plane1, plane2]

    def destroy_flower():
        for child in flower_group.children:
            destroy(child)
        destroy(flower_group)
    flower_group.destroy = destroy_flower
    return flower_group


def add_flowers_in_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    grass_positions = []
    for (lx, ly, lz), btype in blocks.items():
        if btype == 'grass' and ly < CHUNK_SIZE-1:
            if (lx, ly+1, lz) not in blocks:
                grass_positions.append((lx, ly, lz))
    if not grass_positions:
        chunks[key]['flowers'] = []
        return
    num_flowers = min(5, len(grass_positions)//4)
    random.shuffle(grass_positions)
    chunks[key]['flowers'] = []
    for i in range(num_flowers):
        if i >= len(grass_positions):
            break
        lx, ly, lz = grass_positions[i]
        wx = cx * CHUNK_SIZE + lx
        wy = cy * CHUNK_SIZE + ly
        wz = cz * CHUNK_SIZE + lz
        chunks[key]['flowers'].append((wx, wy, wz))


def spawn_flowers_for_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks or 'flowers' not in chunks[key]:
        return
    tex = block_textures.get('flower')
    if tex is None:
        flower_color = color.rgb(255, 100, 150)
    else:
        flower_color = color.white
    entities = []
    for (wx, wy, wz) in chunks[key]['flowers']:
        flower = create_flower_entity(wx, wy+0.5, wz, tex, flower_color)
        entities.append(flower)
    chunks[key]['flower_entities'] = entities


def clear_flowers_for_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key in chunks and 'flower_entities' in chunks[key]:
        for ent in chunks[key]['flower_entities']:
            if ent:
                ent.destroy()
        chunks[key]['flower_entities'] = []

# ---------- 区块生成 ----------


def generate_chunk_blocks(cx, cy, cz):
    blocks = {}
    base_x = cx * CHUNK_SIZE
    base_y = cy * CHUNK_SIZE
    base_z = cz * CHUNK_SIZE
    if cy < 0 or cy > 4:
        return blocks
    for lx in range(CHUNK_SIZE):
        for lz in range(CHUNK_SIZE):
            wx = base_x + lx
            wz = base_z + lz
            height = get_height(wx, wz)
            for ly in range(CHUNK_SIZE):
                wy = base_y + ly
                if wy <= height:
                    if wy == 0:
                        block_type = 'bedrock'
                    elif wy == height:
                        block_type = 'grass'
                    elif wy >= height - 3:
                        block_type = 'dirt'
                    else:
                        block_type = 'stone'
                    blocks[(lx, ly, lz)] = block_type
    return blocks


def add_tree_in_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    candidates = []
    for (lx, ly, lz), btype in blocks.items():
        if btype == 'grass' and ly < CHUNK_SIZE - 5:
            if (lx, ly+1, lz) not in blocks:
                candidates.append((lx, ly, lz))
    if not candidates:
        return
    random.shuffle(candidates)
    for _ in range(min(2, len(candidates)//10 + 1)):
        if not candidates:
            break
        lx, ly, lz = candidates.pop()
        trunk_h = random.randint(3, 4)
        ok = True
        for dy in range(1, trunk_h+1):
            if (lx, ly+dy, lz) in blocks:
                ok = False
                break
        if not ok:
            continue
        for dy in range(1, trunk_h+1):
            blocks[(lx, ly+dy, lz)] = 'wood'
        leaf_radius = 2
        for dx in range(-leaf_radius, leaf_radius+1):
            for dy in range(-leaf_radius, leaf_radius+1):
                for dz in range(-leaf_radius, leaf_radius+1):
                    if dx*dx + dy*dy + dz*dz <= leaf_radius*leaf_radius:
                        nx = lx + dx
                        ny = ly + trunk_h + dy
                        nz = lz + dz
                        if 0 <= nx < CHUNK_SIZE and 0 <= ny < CHUNK_SIZE and 0 <= nz < CHUNK_SIZE:
                            if (nx, ny, nz) not in blocks:
                                blocks[(nx, ny, nz)] = 'leaves'


def add_water_pool_in_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    for (lx, ly, lz), btype in list(blocks.items()):
        if btype == 'grass' and ly < BASE_HEIGHT - 2:
            if (lx, ly+1, lz) not in blocks:
                if random.random() < 0.002:
                    blocks[(lx, ly+1, lz)] = 'water'


def load_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key in chunks:
        if 'entities' not in chunks[key] or not chunks[key]['entities']:
            rebuild_chunk(cx, cy, cz)
        if 'flower_entities' not in chunks[key] or not chunks[key]['flower_entities']:
            spawn_flowers_for_chunk(cx, cy, cz)
        loaded_chunks.add(key)
        return
    blocks = generate_chunk_blocks(cx, cy, cz)
    if not blocks:
        return
    chunks[key] = {'blocks': blocks, 'entities': {}, 'flowers': []}
    add_tree_in_chunk(cx, cy, cz)
    add_water_pool_in_chunk(cx, cy, cz)
    add_flowers_in_chunk(cx, cy, cz)
    rebuild_chunk(cx, cy, cz)
    spawn_flowers_for_chunk(cx, cy, cz)
    loaded_chunks.add(key)


def unload_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key in chunks:
        clear_flowers_for_chunk(cx, cy, cz)
        if 'entities' in chunks[key]:
            for ent in chunks[key]['entities'].values():
                if ent:
                    destroy(ent)
            chunks[key]['entities'] = {}
    if key in loaded_chunks:
        loaded_chunks.remove(key)

# ---------- 动物生成器 ----------


def spawn_animal_for_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    candidates = []
    for (lx, ly, lz), btype in blocks.items():
        if btype == 'grass' and ly < CHUNK_SIZE-1:
            if (lx, ly+1, lz) not in blocks:
                candidates.append((cx*CHUNK_SIZE+lx, ly, cz*CHUNK_SIZE+lz))
    if not candidates:
        return
    x, y, z = random.choice(candidates)
    if random.random() < 0.3:
        animal_type = random.choice(['chicken', 'cow', 'pig'])
        animal = Animal(animal_type, x, z, y)
        animals.append(animal)

# ---------- 区块管理器 ----------


def update_chunks(player_pos):
    cx = int(math.floor(player_pos.x / CHUNK_SIZE))
    cy = int(math.floor(player_pos.y / CHUNK_SIZE))
    cz = int(math.floor(player_pos.z / CHUNK_SIZE))
    needed = set()
    for dx in range(-RENDER_RADIUS, RENDER_RADIUS+1):
        for dy in range(-RENDER_RADIUS, RENDER_RADIUS+1):
            for dz in range(-RENDER_RADIUS, RENDER_RADIUS+1):
                needed.add((cx+dx, cy+dy, cz+dz))
    for key in needed:
        if key not in loaded_chunks:
            load_chunk(*key)
            if random.random() < 0.5:
                spawn_animal_for_chunk(*key)
    to_unload = loaded_chunks - needed
    for key in to_unload:
        unload_chunk(*key)

# ---------- 安全出生点 ----------


def find_safe_spawn():
    search_radius = 50
    for r in range(1, search_radius+1):
        for dx in range(-r, r+1):
            for dz in range(-r, r+1):
                if abs(dx) == r or abs(dz) == r:
                    x = dx
                    z = dz
                    ground_y = get_height(x, z)
                    if ground_y < 2 or ground_y > WORLD_HEIGHT_LIMIT - 2:
                        continue
                    cx = x // CHUNK_SIZE
                    cz = z // CHUNK_SIZE
                    cy = ground_y // CHUNK_SIZE
                    load_chunk(cx, cy, cz)
                    key = (cx, cy, cz)
                    if key not in chunks:
                        continue
                    blocks = chunks[key]['blocks']
                    lx = x - cx*CHUNK_SIZE
                    lz = z - cz*CHUNK_SIZE
                    for ly in range(ground_y, ground_y-5, -1):
                        if (lx, ly, lz) in blocks:
                            btype = blocks[(lx, ly, lz)]
                            if btype in ('grass', 'dirt', 'stone'):
                                if (lx, ly+1, lz) not in blocks and (lx, ly+2, lz) not in blocks:
                                    return (x, ly+1.5, z)
                                break
    return (0, get_height(0, 0)+1.5, 0)

# ---------- 存档/读档 ----------


def save_world():
    data = {
        'chunks': {},
        'player': (player.x, player.y, player.z),
        'inventory': inventory,
        'backpack': backpack,
        'health': player_health,
        'hunger': player_hunger,
        'hotbar': current_hotbar_slot,
        'game_time': game_time,
        'is_raining': is_raining,
        'rain_remain': rain_remain
    }
    for key, chunk_data in chunks.items():
        if chunk_data['blocks']:
            data['chunks'][key] = chunk_data['blocks']
    try:
        with open(WORLD_FILE, 'wb') as f:
            pickle.dump(data, f)
        print(f"世界已保存到 {WORLD_FILE}")
    except Exception as e:
        print(f"保存失败: {e}")


def load_world():
    if not WORLD_FILE.exists():
        return False
    try:
        with open(WORLD_FILE, 'rb') as f:
            data = pickle.load(f)
        for key, blocks in data['chunks'].items():
            chunks[key] = {'blocks': blocks, 'entities': {}, 'flowers': []}
        player_pos = data.get('player', (0, 10, 0))
        if 'inventory' in data:
            global inventory, backpack, player_health, player_hunger, current_hotbar_slot
            inv_data = data['inventory']
            if isinstance(inv_data, list) and len(inv_data) == 9:
                if all(isinstance(item, str) for item in inv_data if item is not None):
                    inventory = [(item, 1) if item else (None, 0)
                                 for item in inv_data]
                else:
                    inventory = inv_data
            bp_data = data.get('backpack', [(None, 0)]*36)
            if isinstance(bp_data, list) and len(bp_data) == 36:
                if all(isinstance(item, str) for item in bp_data if item is not None):
                    backpack = [(item, 1) if item else (None, 0)
                                for item in bp_data]
                else:
                    backpack = bp_data
            player_health = data.get('health', 20)
            player_hunger = data.get('hunger', 20)
            current_hotbar_slot = data.get('hotbar', 0)
        if 'game_time' in data:
            global game_time, is_raining, rain_remain
            game_time = data['game_time']
            is_raining = data.get('is_raining', False)
            rain_remain = data.get('rain_remain', 0.0)
        for key in list(chunks.keys()):
            cx, cy, cz = key
            add_flowers_in_chunk(cx, cy, cz)
        return player_pos
    except Exception as e:
        print(f"读取存档失败: {e}")
        return False

# ---------- 初始化 ----------


def init_world():
    global game_time
    player_pos = load_world()
    if player_pos:
        print("加载存档成功")
        player.position = player_pos
        update_chunks(player_pos)
        update_hotbar_ui()
        update_backpack_ui()
    else:
        print("新建世界，寻找安全出生点...")
        safe_pos = find_safe_spawn()
        player.position = safe_pos
        print(f"出生点: {safe_pos}")
        update_chunks(player.position)
        update_hotbar_ui()
        update_backpack_ui()
        game_time = 360.0


# ---------- 玩家 ----------
player = FirstPersonController(position=(0, 10, 0), enabled=True)
player.collider = 'box'
player.gravity = 1.5

# ---------- 使用 Ursina 内置天空 ----------
Sky()
DirectionalLight()

# ---------- 辅助函数 ----------


def add_to_backpack(item_type):
    if item_type is None:
        return
    for i in range(9):
        if inventory[i][0] == item_type and inventory[i][1] < 64:
            inventory[i] = (item_type, inventory[i][1] + 1)
            update_hotbar_ui()
            return
    for i in range(36):
        if backpack[i][0] == item_type and backpack[i][1] < 64:
            backpack[i] = (item_type, backpack[i][1] + 1)
            if backpack_open:
                update_backpack_ui()
            return
    for i in range(9):
        if inventory[i][0] is None:
            inventory[i] = (item_type, 1)
            update_hotbar_ui()
            return
    for i in range(36):
        if backpack[i][0] is None:
            backpack[i] = (item_type, 1)
            if backpack_open:
                update_backpack_ui()
            return
    print("背包已满！")


def eat_food():
    global player_hunger
    item_type, quantity = inventory[current_hotbar_slot]
    if item_type is None or quantity <= 0:
        print("没有物品可食用")
        return
    if item_type in FOOD_ITEMS:
        restore = FOOD_ITEMS[item_type]
        player_hunger = min(max_hunger, player_hunger + restore)
        if quantity > 1:
            inventory[current_hotbar_slot] = (item_type, quantity - 1)
        else:
            inventory[current_hotbar_slot] = (None, 0)
        update_hotbar_ui()
        print(f"食用了 {item_type}，饥饿值 +{restore}")
    else:
        print(f"{item_type} 不是食物")

# ---------- 挖掘与放置 ----------


def dig():
    if mouse.hovered_entity:
        for monster in monsters:
            if mouse.hovered_entity == monster.vis_group or mouse.hovered_entity == monster:
                monster.take_damage(2)
                print(f"攻击怪物，剩余生命 {monster.health}")
                return
    if not (mouse.hovered_entity and mouse.hovered_entity in [ent for chunk in chunks.values() for ent in chunk['entities'].values() if ent]):
        return
    if mouse.point is None or mouse.normal is None:
        return
    point = mouse.point
    normal = mouse.normal
    bx = int(math.floor(point[0] - normal[0] * 0.5))
    by = int(math.floor(point[1] - normal[1] * 0.5))
    bz = int(math.floor(point[2] - normal[2] * 0.5))
    cx = bx // CHUNK_SIZE
    cy = by // CHUNK_SIZE
    cz = bz // CHUNK_SIZE
    key = (cx, cy, cz)
    if key not in chunks:
        return
    lx = bx - cx*CHUNK_SIZE
    ly = by - cy*CHUNK_SIZE
    lz = bz - cz*CHUNK_SIZE
    if (lx, ly, lz) not in chunks[key]['blocks']:
        return
    block_type = chunks[key]['blocks'][(lx, ly, lz)]
    del chunks[key]['blocks'][(lx, ly, lz)]
    rebuild_chunk(cx, cy, cz)
    for dx, dy, dz in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]:
        nx, ny, nz = cx+dx, cy+dy, cz+dz
        if (nx, ny, nz) in chunks:
            rebuild_chunk(nx, ny, nz)
    add_to_backpack(block_type)
    print(f"挖掘了 {block_type}")


def place_block():
    global current_block_type
    item_type, quantity = inventory[current_hotbar_slot]
    if item_type is None or quantity <= 0 or item_type not in BLOCK_COLORS:
        return
    current_block_type = item_type
    if not (mouse.hovered_entity and mouse.hovered_entity in [ent for chunk in chunks.values() for ent in chunk['entities'].values() if ent]):
        return
    if mouse.point is None or mouse.normal is None:
        return
    point = mouse.point
    normal = mouse.normal
    bx = int(math.floor(point[0] - normal[0] * 0.5))
    by = int(math.floor(point[1] - normal[1] * 0.5))
    bz = int(math.floor(point[2] - normal[2] * 0.5))
    px = bx + int(round(normal[0]))
    py = by + int(round(normal[1]))
    pz = bz + int(round(normal[2]))
    cx = px // CHUNK_SIZE
    cy = py // CHUNK_SIZE
    cz = pz // CHUNK_SIZE
    key = (cx, cy, cz)
    if key not in chunks:
        return
    lx = px - cx*CHUNK_SIZE
    ly = py - cy*CHUNK_SIZE
    lz = pz - cz*CHUNK_SIZE
    if (lx, ly, lz) in chunks[key]['blocks']:
        return
    chunks[key]['blocks'][(lx, ly, lz)] = current_block_type
    rebuild_chunk(cx, cy, cz)
    for dx, dy, dz in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]:
        nx, ny, nz = cx+dx, cy+dy, cz+dz
        if (nx, ny, nz) in chunks:
            rebuild_chunk(nx, ny, nz)
    if quantity > 1:
        inventory[current_hotbar_slot] = (item_type, quantity - 1)
    else:
        inventory[current_hotbar_slot] = (None, 0)
    update_hotbar_ui()
    print(f"放置了 {current_block_type}")

# ---------- 方块切换 ----------


def switch_to_grass(): global current_block_type; current_block_type = 'grass'; print("切换到: 草")
def switch_to_dirt(): global current_block_type; current_block_type = 'dirt'; print("切换到: 泥土")
def switch_to_stone(): global current_block_type; current_block_type = 'stone'; print("切换到: 石头")
def switch_to_bedrock(
): global current_block_type


current_block_type = 'bedrock'
print("切换到: 基岩")
def switch_to_wood(): global current_block_type; current_block_type = 'wood'; print("切换到: 木头")
def switch_to_leaves(): global current_block_type; current_block_type = 'leaves'; print("切换到: 树叶")
def switch_to_water(): global current_block_type; current_block_type = 'water'; print("切换到: 水")

# ---------- 输入 ----------


def input(key):
    global current_block_type, backpack_open, current_hotbar_slot
    if key == 'escape':
        mouse.locked = not mouse.locked
        return
    if key == 'e' and not backpack_open:
        backpack_open = True
        backpack_bg.enabled = True
        backpack_title.enabled = True
        for s in backpack_slots:
            s.enabled = True
        for i in backpack_icons:
            i.enabled = True
        for c in backpack_counts:
            c.enabled = True
        update_backpack_ui()
        mouse.locked = False
        return
    if key == 'e' and backpack_open:
        backpack_open = False
        backpack_bg.enabled = False
        backpack_title.enabled = False
        for s in backpack_slots:
            s.enabled = False
        for i in backpack_icons:
            i.enabled = False
        for c in backpack_counts:
            c.enabled = False
        mouse.locked = True
        return
    if backpack_open:
        return
    if key in '123456789':
        slot = int(key) - 1
        current_hotbar_slot = slot
        item, _ = inventory[slot]
        if item in BLOCK_COLORS:
            current_block_type = item
        update_hotbar_ui()
        return
    if key == 'f' or key == 'F':
        eat_food()
        return
    if key == 'left mouse down':
        dig()
    elif key == 'right mouse down':
        place_block()
    elif key == 'space':
        player.jump()


# ---------- UI ----------
status_text = Text("", position=(-0.8, 0.4), scale=1.0, background=True)
time_text = Text('', position=(0.7, 0.45), scale=1.0,
                 background=True, color=color.white)
weather_text = Text('', position=(0.7, 0.40), scale=1.0,
                    background=True, color=color.white)


def update_ui():
    global player_health, max_health, player_hunger, max_hunger
    health_ratio = max(0, min(1, player_health / max_health))
    health_bar.scale_x = 0.3 * health_ratio
    health_text.text = f"{int(player_health)}/{max_health}"
    hunger_ratio = max(0, min(1, player_hunger / max_hunger))
    hunger_bar.scale_x = 0.3 * hunger_ratio
    hunger_text.text = f"{int(player_hunger)}/{max_hunger}"
    item, qty = inventory[current_hotbar_slot]
    item_name = BLOCK_ITEMS.get(item, item) if item else '空'
    status_text.text = f"""位置: ({player.x:.1f}, {player.y:.1f}, {player.z:.1f})
左键:挖掘/攻击 | 右键:放置 | 空格:跳跃 | E:背包 | F:食用
1-9:选物品 | 物品: {item_name} x{qty if qty > 0 else 0}
加载区块: {len(loaded_chunks)} | 动物: {len(animals)} | 花朵: {len(flower_entities)}"""
    hours = int(game_time // 60) % 24
    minutes = int(game_time % 60)
    time_text.text = f"时间: {hours:02d}:{minutes:02d}"
    if is_raining:
        weather_text.text = f"🌧️ 下雨中 {int(rain_remain)}s"
    else:
        weather_text.text = "☀️ 晴天"

# ---------- 主循环 ----------


def update():
    global game_time, is_raining, rain_remain, player_health, player_hunger, monster_spawn_timer

    # 1. 昼夜循环
    game_time += time.dt * 60
    hour_angle = ((game_time / 60) % 24) / 24 * 360
    sun_angle = hour_angle + 90
    brightness = (math.sin(math.radians(sun_angle)) + 1) / 2
    brightness = max(0.1, brightness)

    # 2. 饥饿值下降
    if not hasattr(update, 'hunger_timer'):
        update.hunger_timer = 0.0
    update.hunger_timer += time.dt
    if update.hunger_timer >= 10.0:
        update.hunger_timer = 0.0
        if player_hunger > 0:
            player_hunger -= 1
            if player_hunger < 0:
                player_hunger = 0

    # 3. 生命恢复
    if player_hunger >= 6 and player_health < max_health:
        if not hasattr(update, 'health_timer'):
            update.health_timer = 0.0
        update.health_timer += time.dt
        if update.health_timer >= 2.0:
            update.health_timer = 0.0
            player_health += 1
            if player_health > max_health:
                player_health = max_health

    # 4. 天气
    if random.random() < rain_chance * time.dt * 60:
        if is_raining:
            rain_remain += rain_base_duration
        else:
            is_raining = True
            rain_remain = rain_base_duration
    if is_raining:
        rain_remain -= time.dt
        if rain_remain <= 0:
            is_raining = False
            rain_remain = 0.0

    # 5. 怪物生成（夜间）
    is_night = brightness < 0.3
    if is_night and player_health > 0:
        monster_spawn_timer -= time.dt
        if monster_spawn_timer <= 0:
            monster_spawn_timer = monster_spawn_interval
            if random.random() < 0.6:
                spawn_pos = player.position + \
                    Vec3(random.uniform(-10, 10), 0, random.uniform(-10, 10))
                ground_y = get_height(int(spawn_pos.x), int(spawn_pos.z))
                spawn_pos.y = ground_y + 1
                if random.random() < 0.5:
                    zombie = Zombie(spawn_pos)
                    monsters.append(zombie)
                else:
                    skeleton = Skeleton(spawn_pos)
                    monsters.append(skeleton)

    # 6. 更新怪物 & 燃烧处理
    for monster in monsters[:]:
        monster.update()
        # 燃烧：白天亮度>0.5时，僵尸和骷髅每秒受1伤害
        if brightness > 0.5 and isinstance(monster, (Zombie, Skeleton)):
            if not hasattr(monster, 'burn_timer'):
                monster.burn_timer = 0.0
            monster.burn_timer += time.dt
            if monster.burn_timer >= 1.0:
                monster.take_damage(1)
                monster.burn_timer = 0.0
            # 闪烁颜色变化：半秒红
            if int(monster.burn_timer * 2) % 2 == 0:
                if monster.vis_group:
                    for child in monster.vis_group.children:
                        if isinstance(child, Entity) and child.model == 'quad':
                            child.color = color.rgb(255, 100, 100)
            else:
                if monster.vis_group:
                    for child in monster.vis_group.children:
                        if isinstance(child, Entity) and child.model == 'quad':
                            child.color = color.white
        # 超出距离销毁
        if distance(monster.position, player.position) > 50:
            monster.destroy()
            if monster in monsters:
                monsters.remove(monster)

    # 7. 更新动物
    for animal in animals:
        animal.update()

    # 8. 玩家死亡重生
    if player_health <= 0:
        print("你死了！重生中...")
        player_health = max_health
        player_hunger = max_hunger
        spawn_x = 0
        spawn_z = 0
        ground_y = get_height(spawn_x, spawn_z)
        player.position = (spawn_x, ground_y + 1.5, spawn_z)
        player.velocity = Vec3(0, 0, 0)
        for monster in monsters[:]:
            monster.destroy()
        monsters.clear()

    # 9. 区块加载
    update_chunks(player.position)

    # 10. 地面修正
    ground = get_height(int(player.x), int(player.z))
    if player.y < ground - 1.0:
        player.y = ground + 1.0
    if player.y < -100:
        player.position = (0, get_height(0, 0)+1.5, 0)
        player.velocity = Vec3(0, 0, 0)
        print("坠落保护：已传送回出生点")

    # 11. UI更新
    update_ui()


def on_application_quit():
    save_world()
    print("游戏已关闭，世界已保存")


app.on_application_quit = on_application_quit

init_world()

print("=== PocketWorld alpha 1.3.1 (贴图模型版 + 怪物燃烧) ===")
print("模组加载: ", [str(p) for p in get_mode_dirs()])
print("存档目录: ", SAVE_DIR)
print("按键: 1-9选物品，E开背包，F食用，左键攻击/挖掘，右键放置，空格跳跃，Escape锁定鼠标")
print("怪物掉落: 僵尸→腐肉，骷髅→骨头")
print("白天怪物会燃烧！")

app.run()
