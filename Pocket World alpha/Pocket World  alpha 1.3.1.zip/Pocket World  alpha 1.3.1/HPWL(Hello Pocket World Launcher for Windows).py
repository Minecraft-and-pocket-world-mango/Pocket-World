import os
import sys
import subprocess

def main():
    # 两个可能的游戏路径
    paths = [
        r"C:\Users\Administrator\Desktop\Pocket World  alpha 1.3.1\code",
        r"D:\Pocket World  alpha 1.3.1\code"
    ]

    script_name = "Main_code.py"
    game_script = None

    for p in paths:
        test_path = os.path.join(p, script_name)
        if os.path.exists(test_path):
            game_script = test_path
            break

    if game_script is None:
        print("❌ 未找到游戏主文件！")
        print("请检查以下路径是否存在 Main_code.py：")
        for p in paths:
            print(f"  {p}")
        input("按 Enter 退出...")
        return

    print(f"✅ 找到游戏脚本：{game_script}")
    print("正在检查 ursina 库...")

    # 检查 ursina 是否已安装
    try:
        import ursina
        print("✅ ursina 已安装")
    except ImportError:
        print("⚠️ 未检测到 ursina，正在自动安装...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "ursina", "-i", "https://pypi.tuna.tsinghua.edu.cn/simple"], check=True)
            print("✅ ursina 安装完成！")
        except Exception as e:
            print(f"❌ 安装失败：{e}")
            print("请手动运行：pip install ursina")
            input("按 Enter 退出...")
            return

    print("正在启动游戏...")
    try:
        # 切换到游戏目录运行
        os.chdir(os.path.dirname(game_script))
        subprocess.run([sys.executable, game_script])
    except Exception as e:
        print(f"❌ 启动失败：{e}")
        input("按 Enter 退出...")

if __name__ == "__main__":
    main()