import os
import sys
import pickle
import importlib.util
import math
import random
from pathlib import Path
from collections import defaultdict
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

# ---------- 动态加载外部 mod ----------


def get_mode_dirs():
    return [
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.2.1/mode"),
        Path("D:/Pocket World alpha 1.2.1/mode")
    ]


def load_mods():
    for mod_path in get_mode_dirs():
        if not mod_path.exists() or not mod_path.is_dir():
            continue
        print(f"发现 mod 目录: {mod_path}")
        for py_file in mod_path.glob("*.py"):
            try:
                module_name = py_file.stem
                spec = importlib.util.spec_from_file_location(
                    module_name, py_file)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)
                    print(f"  已加载 mod: {module_name}")
            except Exception as e:
                print(f"  加载 {py_file.name} 失败: {e}")
        break


load_mods()

# ---------- 存档路径 ----------


def get_save_dir():
    candidates = [
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.2.1/saves"),
        Path("D:/Pocket World alpha 1.2.1/saves")
    ]
    for p in candidates:
        if p.exists():
            return p
    candidates[0].mkdir(parents=True, exist_ok=True)
    return candidates[0]


SAVE_DIR = get_save_dir()
WORLD_FILE = SAVE_DIR / "world.dat"
print(f"存档目录: {SAVE_DIR}")

# ---------- 游戏主程序 ----------
app = Ursina()
window.title = 'PocketWorld Infinite (花模型优化)'
Text.default_font = '微软雅黑'

# ---------- 游戏参数 ----------
CHUNK_SIZE = 16
RENDER_RADIUS = 1
WORLD_HEIGHT_LIMIT = 64
BASE_HEIGHT = 8
AMPLITUDE = 4
SCALE = 80.0

# 方块颜色（回退）
BLOCK_COLORS = {
    'grass':       color.rgb(87, 127, 47),
    'dirt':        color.rgb(98, 67, 28),
    'stone':       color.rgb(127, 127, 127),
    'bedrock':     color.rgb(50, 50, 50),
    'wood':        color.rgb(139, 69, 19),
    'leaves':      color.rgb(34, 139, 34),
    'water':       color.rgb(64, 164, 223, 180)
}
current_block_type = 'grass'

# key: (cx,cy,cz) -> {'blocks': dict, 'entities': {type: Entity}, 'flowers': list}
chunks = {}
animals = []
loaded_chunks = set()
flower_entities = []  # 存储所有花实体，便于清理

crosshair = Entity(model='quad', scale=(0.02, 0.02), parent=camera.ui,
                   texture='white_cube', color=color.white)

# ---------- 加载纹理 ----------


def load_textures():
    textures = {}
    paths = [
        Path("C:/Users/Administrator/Desktop/Pocket World  alpha 1.2.1/modeling"),
        Path("D:/Pocket World alpha 1.2.1/modeling")
    ]
    name_map = {
        'grass': 'grass',
        'dirt': 'dirt',
        'stone': 'stone',
        'bedrock': 'Bedrock',
        'wood': 'wood',
        'leaves': 'Leaf',
        'water': 'water',
        'flower': 'flower'
    }
    for path in paths:
        if not path.exists():
            continue
        for block_type, filename in name_map.items():
            img_path = path / (filename + '.png')
            if img_path.exists():
                try:
                    tex = Texture(str(img_path))
                    textures[block_type] = tex
                    print(f"加载纹理: {block_type} -> {img_path}")
                except Exception as e:
                    print(f"加载纹理 {img_path} 失败: {e}")
        break
    return textures


block_textures = load_textures()

# ---------- Perlin 噪声 ----------


class PerlinNoise:
    def __init__(self, seed=42):
        random.seed(seed)
        self.p = list(range(256))
        random.shuffle(self.p)
        self.p += self.p

    def fade(self, t): return t*t*t*(t*(t*6-15)+10)
    def lerp(self, a, b, t): return a + t*(b-a)

    def grad(self, hash, x, y):
        h = hash & 7
        u = x if h < 4 else y
        v = y if h < 4 else x
        return ((u if (h & 1) == 0 else -u) + (v if (h & 2) == 0 else -v))

    def noise2(self, x, y):
        xi = int(x) & 255
        yi = int(y) & 255
        xf = x - int(x)
        yf = y - int(y)
        u = self.fade(xf)
        v = self.fade(yf)
        aaa = self.p[self.p[xi]+yi]
        aba = self.p[self.p[xi]+yi+1]
        aab = self.p[self.p[xi+1]+yi]
        abb = self.p[self.p[xi+1]+yi+1]
        x1 = self.lerp(self.grad(aaa, xf, yf), self.grad(aab, xf-1, yf), u)
        x2 = self.lerp(self.grad(aba, xf, yf-1), self.grad(abb, xf-1, yf-1), u)
        return (self.lerp(x1, x2, v) + 1.0) / 2.0


noise = PerlinNoise(seed=42)


def get_height(x, z):
    nx = x / SCALE
    nz = z / SCALE
    h = noise.noise2(nx, nz) * AMPLITUDE + BASE_HEIGHT
    return int(max(1, min(WORLD_HEIGHT_LIMIT, h)))

# ---------- 辅助：查询任意世界坐标是否有方块 ----------


def has_block_at(wx, wy, wz):
    cx = wx // CHUNK_SIZE
    cy = wy // CHUNK_SIZE
    cz = wz // CHUNK_SIZE
    key = (cx, cy, cz)
    if key not in chunks:
        return False
    lx = wx - cx * CHUNK_SIZE
    ly = wy - cy * CHUNK_SIZE
    lz = wz - cz * CHUNK_SIZE
    return (lx, ly, lz) in chunks[key]['blocks']

# ---------- 构建某类型方块网格 ----------


def build_chunk_mesh_for_type(block_positions, btype, cx, cy, cz):
    vertices = []
    triangles = []
    uvs = []
    normals = []
    colors = []

    base_x = cx * CHUNK_SIZE
    base_y = cy * CHUNK_SIZE
    base_z = cz * CHUNK_SIZE

    tex = block_textures.get(btype)
    use_texture = tex is not None
    block_color = BLOCK_COLORS.get(btype, color.gray)

    std_uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]

    def add_face(v0, v1, v2, v3, normal):
        idx = len(vertices)
        vertices.extend([v0, v1, v2, v3])
        triangles.extend([idx, idx+1, idx+2, idx, idx+2, idx+3])
        normals.extend([normal]*4)
        if use_texture:
            uvs.extend(std_uvs)
        else:
            colors.extend([block_color]*4)
            uvs.extend([(0, 0), (0, 0), (0, 0), (0, 0)])

    for (lx, ly, lz) in block_positions:
        world_x = base_x + lx
        world_y = base_y + ly
        world_z = base_z + lz

        if not has_block_at(world_x+1, world_y, world_z):
            v0 = (world_x+1, world_y,   world_z)
            v1 = (world_x+1, world_y,   world_z+1)
            v2 = (world_x+1, world_y+1, world_z+1)
            v3 = (world_x+1, world_y+1, world_z)
            add_face(v0, v1, v2, v3, (1, 0, 0))
        if not has_block_at(world_x-1, world_y, world_z):
            v0 = (world_x,   world_y,   world_z+1)
            v1 = (world_x,   world_y,   world_z)
            v2 = (world_x,   world_y+1, world_z)
            v3 = (world_x,   world_y+1, world_z+1)
            add_face(v0, v1, v2, v3, (-1, 0, 0))
        if not has_block_at(world_x, world_y+1, world_z):
            v0 = (world_x,   world_y+1, world_z)
            v1 = (world_x+1, world_y+1, world_z)
            v2 = (world_x+1, world_y+1, world_z+1)
            v3 = (world_x,   world_y+1, world_z+1)
            add_face(v0, v1, v2, v3, (0, 1, 0))
        if not has_block_at(world_x, world_y-1, world_z):
            v0 = (world_x,   world_y, world_z)
            v1 = (world_x+1, world_y, world_z)
            v2 = (world_x+1, world_y, world_z+1)
            v3 = (world_x,   world_y, world_z+1)
            add_face(v0, v1, v2, v3, (0, -1, 0))
        if not has_block_at(world_x, world_y, world_z+1):
            v0 = (world_x,   world_y,   world_z+1)
            v1 = (world_x+1, world_y,   world_z+1)
            v2 = (world_x+1, world_y+1, world_z+1)
            v3 = (world_x,   world_y+1, world_z+1)
            add_face(v0, v1, v2, v3, (0, 0, 1))
        if not has_block_at(world_x, world_y, world_z-1):
            v0 = (world_x+1, world_y,   world_z)
            v1 = (world_x,   world_y,   world_z)
            v2 = (world_x,   world_y+1, world_z)
            v3 = (world_x+1, world_y+1, world_z)
            add_face(v0, v1, v2, v3, (0, 0, -1))

    if vertices:
        mesh = Mesh(vertices=vertices, triangles=triangles,
                    uvs=uvs, normals=normals)
        if use_texture:
            entity = Entity(model=mesh, texture=tex,
                            color=color.white, collider='mesh')
        else:
            entity = Entity(model=mesh, color=block_color, collider='mesh')
        return entity
    else:
        return None

# ---------- 重建区块 ----------


def rebuild_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    chunk_data = chunks[key]
    if 'entities' in chunk_data:
        for ent in chunk_data['entities'].values():
            if ent:
                destroy(ent)
    chunk_data['entities'] = {}
    type_blocks = defaultdict(list)
    for (lx, ly, lz), btype in chunk_data['blocks'].items():
        type_blocks[btype].append((lx, ly, lz))
    for btype, pos_list in type_blocks.items():
        entity = build_chunk_mesh_for_type(pos_list, btype, cx, cy, cz)
        if entity:
            chunk_data['entities'][btype] = entity

# ---------- 花实体（交叉平面）----------


class FlowerEntity(Entity):
    def __init__(self, position, texture=None, flower_color=color.white, **kwargs):
        self.plane1 = Entity(
            model='quad',
            texture=texture,
            color=flower_color,
            position=position,
            scale=(0.5, 0.5, 0.5),
            rotation=(0, 0, 0),
            double_sided=True
        )
        self.plane2 = Entity(
            model='quad',
            texture=texture,
            color=flower_color,
            position=position,
            scale=(0.5, 0.5, 0.5),
            rotation=(0, 90, 0),
            double_sided=True
        )
        # 随机旋转偏移
        angle = random.uniform(0, 360)
        self.plane1.rotation_y = angle
        self.plane2.rotation_y = angle + 90
        self.children = [self.plane1, self.plane2]
        super().__init__(position=position, **kwargs)

    def destroy(self):
        for child in self.children:
            destroy(child)


def create_flower_entity(x, y, z, tex, flower_color=color.white):
    """创建花实体并返回"""
    flower_group = Entity()
    plane1 = Entity(
        model='quad',
        texture=tex,
        color=flower_color,
        position=(x, y, z),
        scale=(0.5, 0.5, 0.5),
        rotation=(0, random.uniform(0, 360), 0),
        double_sided=True,
        parent=flower_group
    )
    plane2 = Entity(
        model='quad',
        texture=tex,
        color=flower_color,
        position=(x, y, z),
        scale=(0.5, 0.5, 0.5),
        rotation=(0, random.uniform(0, 360)+90, 0),
        double_sided=True,
        parent=flower_group
    )
    flower_group.children = [plane1, plane2]

    def destroy_flower():
        for child in flower_group.children:
            destroy(child)
        destroy(flower_group)
    flower_group.destroy = destroy_flower
    return flower_group

# ---------- 生成花朵（改为独立实体）----------


def add_flowers_in_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    # 收集草地位置
    grass_positions = []
    for (lx, ly, lz), btype in blocks.items():
        if btype == 'grass' and ly < CHUNK_SIZE-1:
            if (lx, ly+1, lz) not in blocks:
                grass_positions.append((lx, ly, lz))
    if not grass_positions:
        chunks[key]['flowers'] = []
        return
    # 随机选一些位置生成花
    num_flowers = min(5, len(grass_positions) // 4)
    random.shuffle(grass_positions)
    chunks[key]['flowers'] = []
    for i in range(num_flowers):
        if i >= len(grass_positions):
            break
        lx, ly, lz = grass_positions[i]
        wx = cx * CHUNK_SIZE + lx
        wy = cy * CHUNK_SIZE + ly
        wz = cz * CHUNK_SIZE + lz
        chunks[key]['flowers'].append((wx, wy, wz))


def spawn_flowers_for_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks or 'flowers' not in chunks[key]:
        return
    tex = block_textures.get('flower')
    # 修复 UnboundLocalError：使用 flower_color 代替 color
    if tex is None:
        flower_color = color.rgb(255, 100, 150)  # 粉红
    else:
        flower_color = color.white
    entities = []
    for (wx, wy, wz) in chunks[key]['flowers']:
        flower = create_flower_entity(
            wx, wy+0.5, wz, tex, flower_color=flower_color)
        entities.append(flower)
    chunks[key]['flower_entities'] = entities


def clear_flowers_for_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key in chunks and 'flower_entities' in chunks[key]:
        for ent in chunks[key]['flower_entities']:
            if ent:
                ent.destroy()
        chunks[key]['flower_entities'] = []

# ---------- 区块生成（树、水、花）----------


def generate_chunk_blocks(cx, cy, cz):
    blocks = {}
    base_x = cx * CHUNK_SIZE
    base_y = cy * CHUNK_SIZE
    base_z = cz * CHUNK_SIZE
    if cy < 0 or cy > 4:
        return blocks
    for lx in range(CHUNK_SIZE):
        for lz in range(CHUNK_SIZE):
            wx = base_x + lx
            wz = base_z + lz
            height = get_height(wx, wz)
            for ly in range(CHUNK_SIZE):
                wy = base_y + ly
                if wy <= height:
                    if wy == 0:
                        block_type = 'bedrock'
                    elif wy == height:
                        block_type = 'grass'
                    elif wy >= height - 3:
                        block_type = 'dirt'
                    else:
                        block_type = 'stone'
                    blocks[(lx, ly, lz)] = block_type
    return blocks


def add_tree_in_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    candidates = []
    for (lx, ly, lz), btype in blocks.items():
        if btype == 'grass' and ly < CHUNK_SIZE - 5:
            if (lx, ly+1, lz) not in blocks:
                candidates.append((lx, ly, lz))
    if not candidates:
        return
    random.shuffle(candidates)
    for _ in range(min(2, len(candidates)//10 + 1)):
        if not candidates:
            break
        lx, ly, lz = candidates.pop()
        trunk_h = random.randint(3, 4)
        ok = True
        for dy in range(1, trunk_h+1):
            if (lx, ly+dy, lz) in blocks:
                ok = False
                break
        if not ok:
            continue
        for dy in range(1, trunk_h+1):
            blocks[(lx, ly+dy, lz)] = 'wood'
        leaf_radius = 2
        for dx in range(-leaf_radius, leaf_radius+1):
            for dy in range(-leaf_radius, leaf_radius+1):
                for dz in range(-leaf_radius, leaf_radius+1):
                    if dx*dx + dy*dy + dz*dz <= leaf_radius*leaf_radius:
                        nx = lx + dx
                        ny = ly + trunk_h + dy
                        nz = lz + dz
                        if 0 <= nx < CHUNK_SIZE and 0 <= ny < CHUNK_SIZE and 0 <= nz < CHUNK_SIZE:
                            if (nx, ny, nz) not in blocks:
                                blocks[(nx, ny, nz)] = 'leaves'


def add_water_pool_in_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    for (lx, ly, lz), btype in list(blocks.items()):
        if btype == 'grass' and ly < BASE_HEIGHT - 2:
            if (lx, ly+1, lz) not in blocks:
                if random.random() < 0.002:
                    blocks[(lx, ly+1, lz)] = 'water'


def load_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key in chunks:
        if 'entities' not in chunks[key] or not chunks[key]['entities']:
            rebuild_chunk(cx, cy, cz)
        if 'flower_entities' not in chunks[key] or not chunks[key]['flower_entities']:
            spawn_flowers_for_chunk(cx, cy, cz)
        loaded_chunks.add(key)
        return
    blocks = generate_chunk_blocks(cx, cy, cz)
    if not blocks:
        return
    chunks[key] = {'blocks': blocks, 'entities': {}, 'flowers': []}
    add_tree_in_chunk(cx, cy, cz)
    add_water_pool_in_chunk(cx, cy, cz)
    add_flowers_in_chunk(cx, cy, cz)
    rebuild_chunk(cx, cy, cz)
    spawn_flowers_for_chunk(cx, cy, cz)
    loaded_chunks.add(key)


def unload_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key in chunks:
        clear_flowers_for_chunk(cx, cy, cz)
        if 'entities' in chunks[key]:
            for ent in chunks[key]['entities'].values():
                if ent:
                    destroy(ent)
            chunks[key]['entities'] = {}
    if key in loaded_chunks:
        loaded_chunks.remove(key)

# ---------- 动物 ----------


class Animal(Entity):
    def __init__(self, animal_type, x, z, ground_y):
        self.animal_type = animal_type
        if animal_type == 'chicken':
            scale = (0.5, 0.5, 0.5)
            animal_color = color.yellow
            speed = 0.025
            name_color = color.orange
        elif animal_type == 'cow':
            scale = (0.8, 0.8, 0.8)
            animal_color = color.rgb(101, 67, 33)
            speed = 0.018
            name_color = color.brown
        else:
            scale = (0.7, 0.7, 0.7)
            animal_color = color.pink
            speed = 0.02
            name_color = color.magenta

        super().__init__(
            model='cube',
            color=animal_color,
            position=(x, ground_y + 0.5, z),
            scale=scale,
            collider='box'
        )
        eye = Entity(model='cube', color=color.white, scale=(0.15, 0.15, 0.15),
                     position=(0.2, 0.2, 0.45), parent=self)
        pupil = Entity(model='cube', color=color.black, scale=(0.08, 0.08, 0.08),
                       position=(0.25, 0.25, 0.5), parent=self)

        self.speed = speed
        self.move_dir = Vec3(random.uniform(-1, 1), 0,
                             random.uniform(-1, 1)).normalized()
        self.dir_timer = random.uniform(1, 3)
        self.ground_y = ground_y
        self.name_tag = Text(text=animal_type.capitalize(),
                             position=self.position+(0, 0.7, 0),
                             scale=0.5, color=name_color, origin=(0, 0), world=True)
        self.walk_time = 0

    def update(self):
        self.dir_timer -= time.dt
        if self.dir_timer <= 0:
            self.move_dir = Vec3(random.uniform(-1, 1), 0,
                                 random.uniform(-1, 1)).normalized()
            self.dir_timer = random.uniform(1, 3)
        new_x = self.x + self.move_dir.x * self.speed
        new_z = self.z + self.move_dir.z * self.speed
        if not (-1000 < new_x < 1000 and -1000 < new_z < 1000):
            self.move_dir = -self.move_dir
            return
        ground = get_height(int(new_x), int(new_z))
        if abs(ground - self.ground_y) > 1.5:
            self.move_dir = Vec3(random.uniform(-1, 1), 0,
                                 random.uniform(-1, 1)).normalized()
            return
        self.x = new_x
        self.z = new_z
        self.ground_y = ground
        self.y = ground + 0.5 + math.sin(self.walk_time)*0.03
        self.walk_time += time.dt * 12
        self.name_tag.position = self.position + (0, 0.7, 0)


def spawn_animal_for_chunk(cx, cy, cz):
    key = (cx, cy, cz)
    if key not in chunks:
        return
    blocks = chunks[key]['blocks']
    candidates = []
    for (lx, ly, lz), btype in blocks.items():
        if btype == 'grass' and ly < CHUNK_SIZE-1:
            if (lx, ly+1, lz) not in blocks:
                candidates.append((cx*CHUNK_SIZE+lx, ly, cz*CHUNK_SIZE+lz))
    if not candidates:
        return
    x, y, z = random.choice(candidates)
    if random.random() < 0.3:
        animal_type = random.choice(['chicken', 'cow', 'pig'])
        animal = Animal(animal_type, x, z, y)
        animals.append(animal)

# ---------- 区块管理器 ----------


def update_chunks(player_pos):
    cx = int(math.floor(player_pos.x / CHUNK_SIZE))
    cy = int(math.floor(player_pos.y / CHUNK_SIZE))
    cz = int(math.floor(player_pos.z / CHUNK_SIZE))
    needed = set()
    for dx in range(-RENDER_RADIUS, RENDER_RADIUS+1):
        for dy in range(-RENDER_RADIUS, RENDER_RADIUS+1):
            for dz in range(-RENDER_RADIUS, RENDER_RADIUS+1):
                needed.add((cx+dx, cy+dy, cz+dz))
    for key in needed:
        if key not in loaded_chunks:
            load_chunk(*key)
            if random.random() < 0.5:
                spawn_animal_for_chunk(*key)
    to_unload = loaded_chunks - needed
    for key in to_unload:
        unload_chunk(*key)

# ---------- 安全出生点查找 ----------


def find_safe_spawn():
    search_radius = 50
    for r in range(1, search_radius+1):
        for dx in range(-r, r+1):
            for dz in range(-r, r+1):
                if abs(dx) == r or abs(dz) == r:
                    x = dx
                    z = dz
                    ground_y = get_height(x, z)
                    if ground_y < 2 or ground_y > WORLD_HEIGHT_LIMIT - 2:
                        continue
                    cx = x // CHUNK_SIZE
                    cz = z // CHUNK_SIZE
                    cy = ground_y // CHUNK_SIZE
                    load_chunk(cx, cy, cz)
                    key = (cx, cy, cz)
                    if key not in chunks:
                        continue
                    blocks = chunks[key]['blocks']
                    lx = x - cx*CHUNK_SIZE
                    lz = z - cz*CHUNK_SIZE
                    for ly in range(ground_y, ground_y-5, -1):
                        if (lx, ly, lz) in blocks:
                            btype = blocks[(lx, ly, lz)]
                            if btype in ('grass', 'dirt', 'stone'):
                                if (lx, ly+1, lz) not in blocks and (lx, ly+2, lz) not in blocks:
                                    return (x, ly+1.5, z)
                                break
    return (0, get_height(0, 0)+1.5, 0)

# ---------- 存档/读档 ----------


def save_world():
    data = {
        'chunks': {},
        'player': (player.x, player.y, player.z)
    }
    for key, chunk_data in chunks.items():
        if chunk_data['blocks']:
            data['chunks'][key] = chunk_data['blocks']
    try:
        with open(WORLD_FILE, 'wb') as f:
            pickle.dump(data, f)
        print(f"世界已保存到 {WORLD_FILE}")
    except Exception as e:
        print(f"保存失败: {e}")


def load_world():
    if not WORLD_FILE.exists():
        return False
    try:
        with open(WORLD_FILE, 'rb') as f:
            data = pickle.load(f)
        for key, blocks in data['chunks'].items():
            chunks[key] = {'blocks': blocks, 'entities': {}, 'flowers': []}
        player_pos = data.get('player', (0, 10, 0))
        # 为每个区块生成花（不改变地形）
        for key in list(chunks.keys()):
            cx, cy, cz = key
            add_flowers_in_chunk(cx, cy, cz)
        return player_pos
    except Exception as e:
        print(f"读取存档失败: {e}")
        return False

# ---------- 初始化 ----------


def init_world():
    player_pos = load_world()
    if player_pos:
        print("加载存档成功")
        player.position = player_pos
        update_chunks(player_pos)
    else:
        print("新建世界，寻找安全出生点...")
        safe_pos = find_safe_spawn()
        player.position = safe_pos
        print(f"出生点: {safe_pos}")
        update_chunks(player.position)


# ---------- 玩家 ----------
player = FirstPersonController(position=(0, 10, 0), enabled=True)
player.collider = 'box'
player.gravity = 1.5

Sky()
DirectionalLight()

# ---------- 挖掘与放置 ----------


def dig():
    if not (mouse.hovered_entity and mouse.hovered_entity in [ent for chunk in chunks.values() for ent in chunk['entities'].values() if ent]):
        return
    if mouse.point is None or mouse.normal is None:
        return
    point = mouse.point
    normal = mouse.normal
    bx = int(math.floor(point[0] - normal[0] * 0.5))
    by = int(math.floor(point[1] - normal[1] * 0.5))
    bz = int(math.floor(point[2] - normal[2] * 0.5))
    cx = bx // CHUNK_SIZE
    cy = by // CHUNK_SIZE
    cz = bz // CHUNK_SIZE
    key = (cx, cy, cz)
    if key not in chunks:
        return
    lx = bx - cx*CHUNK_SIZE
    ly = by - cy*CHUNK_SIZE
    lz = bz - cz*CHUNK_SIZE
    if (lx, ly, lz) not in chunks[key]['blocks']:
        return
    del chunks[key]['blocks'][(lx, ly, lz)]
    rebuild_chunk(cx, cy, cz)
    for dx, dy, dz in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]:
        nx, ny, nz = cx+dx, cy+dy, cz+dz
        if (nx, ny, nz) in chunks:
            rebuild_chunk(nx, ny, nz)


def place_block():
    if not (mouse.hovered_entity and mouse.hovered_entity in [ent for chunk in chunks.values() for ent in chunk['entities'].values() if ent]):
        return
    if mouse.point is None or mouse.normal is None:
        return
    point = mouse.point
    normal = mouse.normal
    bx = int(math.floor(point[0] - normal[0] * 0.5))
    by = int(math.floor(point[1] - normal[1] * 0.5))
    bz = int(math.floor(point[2] - normal[2] * 0.5))
    px = bx + int(round(normal[0]))
    py = by + int(round(normal[1]))
    pz = bz + int(round(normal[2]))
    cx = px // CHUNK_SIZE
    cy = py // CHUNK_SIZE
    cz = pz // CHUNK_SIZE
    key = (cx, cy, cz)
    if key not in chunks:
        return
    lx = px - cx*CHUNK_SIZE
    ly = py - cy*CHUNK_SIZE
    lz = pz - cz*CHUNK_SIZE
    if (lx, ly, lz) in chunks[key]['blocks']:
        return
    chunks[key]['blocks'][(lx, ly, lz)] = current_block_type
    rebuild_chunk(cx, cy, cz)
    for dx, dy, dz in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]:
        nx, ny, nz = cx+dx, cy+dy, cz+dz
        if (nx, ny, nz) in chunks:
            rebuild_chunk(nx, ny, nz)

# ---------- 方块切换 ----------


def switch_to_grass(): global current_block_type; current_block_type = 'grass'; print("切换到: 草")
def switch_to_dirt(): global current_block_type; current_block_type = 'dirt'; print("切换到: 泥土")
def switch_to_stone(): global current_block_type; current_block_type = 'stone'; print("切换到: 石头")
def switch_to_bedrock(
): global current_block_type


current_block_type = 'bedrock'
print("切换到: 基岩")
def switch_to_wood(): global current_block_type; current_block_type = 'wood'; print("切换到: 木头")
def switch_to_leaves(): global current_block_type; current_block_type = 'leaves'; print("切换到: 树叶")
def switch_to_water(): global current_block_type; current_block_type = 'water'; print("切换到: 水")

# ---------- 输入 ----------


def input(key):
    if key == 'escape':
        mouse.locked = not mouse.locked
    if key == 'left mouse down':
        dig()
    if key == 'right mouse down':
        place_block()
    if key == '1':
        switch_to_grass()
    if key == '2':
        switch_to_dirt()
    if key == '3':
        switch_to_stone()
    if key == '4':
        switch_to_bedrock()
    if key == '5':
        switch_to_wood()
    if key == '6':
        switch_to_leaves()
    if key == '7':
        switch_to_water()
    if key == 'space':
        player.jump()


# ---------- UI ----------
status_text = Text("", position=(-0.8, 0.4), scale=1.0, background=True)


def update_ui():
    status_text.text = f"""方块: {current_block_type}
位置: ({player.x:.1f}, {player.y:.1f}, {player.z:.1f})
左键:挖掘 | 右键:放置 | 空格:跳跃
1草 2泥土 3石头 4基岩 5木头 6树叶 7水
加载区块: {len(loaded_chunks)} | 动物: {len(animals)} | 花朵: {len(flower_entities)}"""

# ---------- 主循环 ----------


def update():
    update_chunks(player.position)
    for animal in animals:
        animal.update()
    ground = get_height(int(player.x), int(player.z))
    if player.y < ground - 1.0:
        player.y = ground + 1.0
    if player.y < -100:
        player.position = (0, get_height(0, 0)+1.5, 0)
        player.velocity = Vec3(0, 0, 0)
        print("坠落保护：已传送回出生点")
    update_ui()


def on_application_quit():
    save_world()
    print("游戏已关闭，世界已保存")


app.on_application_quit = on_application_quit

init_world()

print("=== PocketWorld 无限版（花模型优化，错误修复） ===")
print("模组加载: ", [str(p) for p in get_mode_dirs()])
print("存档目录: ", SAVE_DIR)
print("花使用交叉平面模型，并加载 flower.png 贴图")
print("按键: 1-7 切换方块，左键挖掘，右键放置，空格跳跃，Escape锁定鼠标")

app.run()
